
import java.util.Scanner;


public class Principal {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);


		Empresa emp1 = new Empresa();
		String respuesta, codigoJ, codigoO, repetir, codigoB;
		int n,p;

		System.out.println("             MENU");
		System.out.println(" ");
		do{
			System.out.println("1) A�adir empleado"
					+ "\n2) Subir sueldo"
					+ "\n3) Listar obreros de un jefe"
					+ "\n4) Mostrar jefe de un obrero"
					+ "\n5) Listar todos los empleados"
					+ "\n6) Borrar Empleado"
					+ "\n7) Ordenar empleados por nombre"  //cambio por codigo
					+ "\n8) Ordenar empleados por sueldo"
					+ "\n9) Listar obreros de un jefe (Iterator)"
					+ "\n10) Listar empleados con sueldo mayor que 2000");


			n=entrada.nextInt();
			switch(n){

			case 1:
				do{
					emp1.agregarEmp();
					System.out.println("Agregar otro empleado: s/n");
					respuesta=entrada.next();
				}
				while(respuesta.equalsIgnoreCase("s"));
				break;

			case 2:
				System.out.println("Introduce el porcentaje de subida");
				p=entrada.nextInt();
				emp1.subirSueldo(p);
				break;

			case 3:
				System.out.println("Introduce el codigo del jefe ");
				codigoJ=entrada.next();
				emp1.listarObrerosJ(codigoJ);
				break;

			case 4:
				System.out.println("Introduce el codigo del obrero");
				codigoO=entrada.next();
				emp1.listarJefeO(codigoO);
				break;

			case 5:
				emp1.listarEmpleados();
				break;

			case 6:
				System.out.println("Introduce el codigo del empleado");
				codigoB=entrada.next();
				emp1.borrarEmpleado(codigoB);
				break;
			
			case 7: 
				emp1.ordenarNombre();
				System.out.println("Se han ordenado los empleados por nombre");
				break;
				
			case 8:
				emp1.ordSuel();
				System.out.println("Se han ordenado los empleados por sueldo");
				break;
				
			case 9:
				System.out.println("Introduce el codigo del jefe ");
				codigoJ=entrada.next();
				emp1.listarObrerosJIterator(codigoJ);
				
			case 10: 
				emp1.sueldoMayor();
			}
			System.out.println("Deseas realizar otra operacion s/n");
			repetir=entrada.next();
			
		}while(repetir.equalsIgnoreCase("s"));
		System.out.println("Fin");
	}

}
