package arrayIteratorIterable;

import java.util.Iterator;

public class Array implements Iterable<Asignatura> {

	private int longitud;
	private Asignatura[]arrayAsig;
	
	public  Array() {
		
		longitud=4;
		
		arrayAsig= new Asignatura[longitud];
		
		arrayAsig[0]= new Asignatura("A1", "matematicas", 10);
		arrayAsig[1]= new Asignatura("A2", "fisica", 6);
		arrayAsig[2]= new Asignatura("A3", "quimica", 4);
		

		
	}
		
		

	public Iterator<Asignatura> iterator(){
		Iterator<Asignatura> it= new iteratorArray(arrayAsig);
		return it;
	}



	public static void main(String[] args) {
		
		Array arr1 = new Array();
		//Iterator <Asignatura> it = arr1.iterator(); //para iterable esto no hace falta  
	
		/*
		while (it.hasNext()) {
			Asignatura asi =  it.next();
			System.out.println(asi.toString());
		}
		*/
		
		for(Asignatura asi : arr1)		//para recorrerlo con un iterable a�adir el implements, porque estamos usando el iterator del ej anterior y recorrerlo con el for each
			System.out.println(asi.toString());
	}



	
	
	
}