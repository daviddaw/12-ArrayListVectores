package arrayIteratorIterable;



public class Asignatura {
	
	String codigo;
	String nombre; 
	int nHoras;
	
	
	public Asignatura() {
		
	}
	
	public Asignatura(String codigo, String nombre, int nHoras) {
		this.codigo=codigo; 
		this.nombre=nombre; 
		this.nHoras=nHoras;
		
	}
	
	
	
	public String getCodigo() {
		return codigo;
	}
	
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	
	public String getNombre() {
		return nombre;
	}
	
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	public int getnHoras() {
		return nHoras;
	}
	
	
	public void setnHoras(int nHoras) {
		this.nHoras = nHoras;
	}
	
	
	
	
	@Override
	public String toString() {
		return "Asignatura [codigo=" + codigo + ", nombre=" + nombre + ", nHoras=" + nHoras + "]";
	}
	
	

}
