
public class Obreros extends Empleados{
	
	private static int c;
	private String codigoO;
	private Jefes jefe;
	
	
	
	public Obreros(String nombre, int edad, double sueldo, Jefes jefe) {
		super(nombre, edad , sueldo);
		c++;
		codigoO="O"+c;
		this.jefe=jefe;
	}

	


	public static int getC() {
		return c;
	}




	public static void setC(int c) {
		Obreros.c = c;
	}




	public String getCodigoO() {
		return codigoO;
	}




	public void setCodigoO(String codigoO) {
		this.codigoO = codigoO;
	}




	public Jefes getJefe() {
		return jefe;
	}




	public void setJefe(Jefes jefe) {
		this.jefe = jefe;
	}




	@Override
	public String toString() {
		if(jefe!=null)
		return super.toString()+ " Obreros [codigoO=" + codigoO + ", jefe=" + jefe.getNombre() + "]";
		else 
			return
					super.toString() + " [codigoO=" + codigoO + ", jefe=Sin jefe]";
	}



}

	
