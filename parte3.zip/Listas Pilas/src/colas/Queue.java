package colas;

import pilas.SNode;

public class Queue <E> implements IQueue<E>{
	
	public SNode<E> front, tail;	
	public int size;
	
	public Queue() {
		size=0; 
		front=tail=null;
	}	
	
	
	public E dequeue() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
			return null;
		}
		E temp=front.element;
		front=front.next;
		size--;
		if (size==0) tail=null;
		return temp;
	}		
	
	
	public void enqueue(E e) {
		SNode<E> newNodo=new SNode<E>(e,null);
		if (isEmpty()) front=newNodo; 
		else tail.next=newNodo;
		tail=newNodo;
		size++;
	}	


	public E front() {
		if (isEmpty()) {
			System.out.println("Queue is empty");
			return null;
		}
		return front.element;
	}

	
	public int size() { 
		return (size); 
		}
	
	
	public boolean isEmpty() { 
		return (size==0); 
		}
	

}
