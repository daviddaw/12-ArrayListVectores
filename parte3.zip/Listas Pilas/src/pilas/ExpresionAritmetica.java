package pilas;

import java.util.Scanner;


public class ExpresionAritmetica{

	public static void main(String[] args) {
		
		


		Scanner entrada = new Scanner(System.in);


		Stack<Character> pila = new Stack<Character>();

		char a1, a2, a3, a4, a5, a6;
		String expresion;
		boolean balanceada=true;

		System.out.println("Introduce una expresion aritmetica");
		expresion=entrada.next();

		a1='(';
		a2='[';
		a3='{';



		for(int i=0; i<expresion.length() && balanceada; i++) {
			if(expresion.charAt(i)==a2 || expresion.charAt(i)==a1 || expresion.charAt(i)==a3) 
				pila.push(expresion.charAt(i));

			else 
				if(expresion.charAt(i)==')' && pila.pop()!=a1) 
					balanceada=false;
				else 
					if(expresion.charAt(i)==']' && pila.pop()!=a2) 
						balanceada=false;
					else 
						if(expresion.charAt(i)=='}' && pila.pop()!=a3) 
							balanceada=false;		


		}


		if(balanceada && pila.isEmpty()) 
			System.out.println("es correcta");
		else 
			System.out.println("no es correcta");



	}

}

