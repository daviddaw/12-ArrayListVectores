package pilas;


public class Stack <E> implements IStack<E>{

	public SNode<E> head;
	public int size;

	public Stack() {
		head=null; 
		size=0;
	}


	public boolean isEmpty() {
		if(size==0)
			return true;
		else 
			return false;
	}


	public void push(E obj) {//a�adir apilar
		SNode<E> nodo = new SNode<E>(obj);
		nodo.next=head;
		head=nodo;
		size++;

	}


	public E pop() {// desapilar
		if(head ==null)
			return null; 
		else {
			E borrado= head.element;
			head=head.next;
			size--;
			return borrado;
		}

	}


	public E top() {//muestra el superior	

		return head.element;
	}


	public int size() {
		return size;
	}
	
	
	

}
