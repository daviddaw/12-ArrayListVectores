package pilas;


public class SNode<E> {

	E element; 
	SNode<E> next;
	
	
	public SNode() {
		element=null; 
		next=null;
	}
	
	public SNode(E obj, SNode<E> nx) {
		element= obj;
		next=nx;
	}
	
	
	public SNode(E obj) {
		element=obj; 
		next=null;
	}

	public E getElement() {
		return element;
	}

	public void setElement(E element) {
		this.element = element;
	}

	public SNode<E> getNext() {
		return next;
	}

	public void setNext(SNode<E> next) {
		this.next = next;
	}
	
	public void verNode() {
		System.out.println(element.toString());
	}
	
	
}

