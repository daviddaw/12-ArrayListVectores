package pilas;

import java.util.Scanner;


public class pila {

	public static void main(String[] args) {
		
		

		Scanner entrada = new Scanner(System.in);


		Stack<Character> pila = new Stack<Character>();

		String contrario="";

		System.out.println("Introduce una palabra");
		String palabra;
		palabra=entrada.next();

		for(int i=0; i<palabra.length(); i++)
			pila.push(palabra.charAt(i));



		while(!pila.isEmpty())
			contrario+=pila.pop();

		System.out.println(contrario);



			
		
		/*	IMPLEMENTANDO LAS PROPIAS CLASES DE JAVA
		Stack<Character> pila = new Stack<Character>();
		System.out.println("Introduce una palabra");
		String palabra,contrario="";
		palabra=entrada.next();
		
		for(int i=0; i<palabra.length(); i++)
			pila.push(palabra.charAt(i));
		
		while(!pila.isEmpty())
		contrario+=pila.pop();

		System.out.println(contrario);
		
		*/
		
		
		
	}

}
