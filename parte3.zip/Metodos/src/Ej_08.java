
public class Ej_08 {

	public static void main(String[] args) {
		// 8.	Escribir un m�todo que recibe como par�metro un n� y devuelva su factorial.
		//Escribir un main que pida por teclado un N>=0 e invoque a dicho m�todo.


		int n;
		System.out.println("Introduce un numero");
		n=LeerTeclado.readInteger();
		while(n<0) {
			System.out.println("Introduce un numero");
			n=LeerTeclado.readInteger();
		}
		System.out.println(Factorial(n));

	}

	public static int Factorial(int n) {
		int fac=1;
		for(int i=1; i<=n; i++)
			fac*=i;
		return fac;
	}
}
