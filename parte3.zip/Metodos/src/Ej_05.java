
public class Ej_05 {

	public static void main(String[] args) {
		// 5.	Usando el m�todo del apartado 4, obtener todos los primos de 2 a N introducido por teclado
		
		int n;
		System.out.println("Introduce un numero");
		n=LeerTeclado.readInteger();
		for(int i=2; i<=n; i++) {
			if(Ej_04.numPrimo(i)==true)
				System.out.println(i);

		}

	}

}
