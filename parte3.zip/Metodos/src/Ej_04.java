import java.util.Scanner;

public class Ej_04 {

	public static void main(String[] args) {
		// 4.	Escribir un m�todo que reciba como par�metro un n� y devuelva si es o no primo. 
		//Escribir un main que pida un n� por teclado mayor que 1 y determine si es o no primo invocando a dicho m�todo.

		Scanner entrada = new Scanner(System.in);

		int n;
		System.out.println("Introduce un numero");
		n = entrada.nextInt();
		if(numPrimo(n))
			System.out.println("Son primos");
		else
			System.out.println("No son primos");


	}
	public static boolean numPrimo(int n) {

		if(n%2==0)
			return false;
		else
			return true;


	}

}
