
public class Ej_01 {

	public static void main(String[] args) {
		// 1.	Escribir un m�todo que reciba como par�metro dos n�meros y devuelva su  suma. An�logamente, 
		//crear varios m�todos para  la resta, el producto y la divisi�n. Escribir un main que pida dos n�meros
		//y una opci�n entre 1 y 4 y seg�n dicha opci�n invoque al m�todo de suma, resta, producto o divisi�n

		int a,b,n; 
		System.out.println("introduce 2 numeros");
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();
		do {
			System.out.println("Introduce 1 para suma, 2 para resta, 3 para multiplicacion y 4 para division");
			n=LeerTeclado.readInteger();
		}while(n<1 || n>4);
		
		switch(n) {
		case 1: System.out.println(sumNum(a, b));
		break;

		case 2: System.out.println(resNum(a, b));
		break;

		case 3: System.out.println(multNum(a, b));
		break;

		case 4: 
			if(b!=0)
				System.out.println(divNum(a, b));
			else 
				System.out.println("No se puede dividir entre 0");
		}




	}

	public static int sumNum(int a,int b) {
		return a+b;

	}

	public static int resNum(int a, int b) {
		return a-b;
	}

	public static int multNum(int a, int b) {
		return a*b;
	}

	public static int divNum(int a, int b) {
		return a/b;
	}

}
