
public class Ej_07 {

	public static void main(String[] args) {
		// 7.	Escribir un m�todo que reciba por par�metro un n� y devuelva la suma de sus divisores, salvo �l mismo. 
		//Utilizando este m�todo, escribir un main para obtener todos los n�meros perfectos menores que un N introducido por teclado.
		int n;
		System.out.println("Introduce un numero");
		n=LeerTeclado.readInteger();
		for(int i=1; i<=n; i++)
			if(SumDiv(i)==i)
				System.out.println("el numero "+i+" es perfecto");
		
		
	}
	
	
	
	public static int SumDiv(int n) {
		int suma=0;
		for(int i=1; i<n; i++)
			if(n%i==0)
				suma=suma+i;
		
		return suma;
	}
}
