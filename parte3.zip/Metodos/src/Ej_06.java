
public class Ej_06 {

	public static void main(String[] args) {
		// 6.	Usando el m�todo del apartado 4, obtener los N primeros n�meros primos siendo N un n� introducido por teclado.

		int n,m=3;
		System.out.println("Introduce el numero de primos que quieres");
		n=LeerTeclado.readInteger();

		for(int i=1; i<=n; i++) {
			do {
				Ej_04.numPrimo(m);

				if(Ej_04.numPrimo(m)==true) {
					System.out.println(m);
				}
				m+=2;
			}while(!Ej_04.numPrimo(m));
		}

	}

}
