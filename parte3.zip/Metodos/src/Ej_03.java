
public class Ej_03 {

	public static void main(String[] args) {
		// 3.	Escribir un m�todo que reciba dos par�metros y decida si uno es divisor del otro. 
		//Escribir un main que introduzca dichos n�meros e invoque al m�todo.
		int a,b;
		System.out.println("Introduce 2 numeros");
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();

		if(divisorNum(a, b))
			System.out.println("Uno es divisor del otro");
		else 
			System.out.println("No son divisores");
	}

	public static boolean divisorNum(int a, int b) {
		if(a%b==0) 
			return true;
		else 
			if(b%a==0)
				return true;
			else
				return false;


	}
}
