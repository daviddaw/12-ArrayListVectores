import java.util.Scanner;

public class Ej_02 {

	public static void main(String[] args) {
		// 2.	Escribir un m�todo que reciba como par�metros dos n�meros y devuelva el menor de los dos. Si son iguales, devolver� uno de ellos.
		Scanner entrada = new Scanner(System.in);
		
		int a,b;
		System.out.println("Introduce 2 numeros");
		a = entrada.nextInt();
		b = entrada.nextInt();
		
		System.out.println( numMenor(a, b));
		
	}
		public static int numMenor(int a, int b) {
		
		if (a>b) 
			return b;

		else 
			return a;
				
		}
		
		
	

}
