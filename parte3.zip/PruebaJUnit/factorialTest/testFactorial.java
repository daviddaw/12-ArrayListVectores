import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class testFactorial {

	private Factorial fac;
	
	@BeforeEach
	void setUp() throws Exception {
		fac = new Factorial(3);
		
	}

	@Test
	void testNormal() throws Exception {
		int esperado=6;
		assertTrue(fac.calculo()==esperado);
		
	}

	
	@Test
	void testCero() throws Exception {
		int esperado=6;
		assertTrue(fac.calculo()==esperado);
		
	}
	
	
}
