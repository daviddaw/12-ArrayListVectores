package test1;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import paquete1.Operaciones;

public class pp1 {
	private Operaciones op;

	@BeforeEach
	public void setUp() throws Exception {
		op=new Operaciones(5, 5);
	}

	@Test
	public void testSuma() {
		int r=op.suma();
		assertTrue(r==10);

	}
	@Test
	public void testResta() {
		int r=op.resta();
		assertTrue(r==0);
	}
	
}
