package test1;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import paquete1.Producto;

public class testProducto {
	private Producto p;

	@BeforeEach
	public void setUp() throws Exception {
		p= new Producto(4, 5);
	}

	@Test
	public void test() {
		int r=p.multiplicar();
		assertTrue(r==20);

	}

}
