package test1;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import paquete2.Division;

public class testDivision {

	private Division d; 


	@BeforeEach
	public void setUp() throws Exception {
		d=new Division(20, 5);
	}

	@Test
	public void test() {
		int r=d.dividir();
		assertTrue(r==4);
	}

	@Test
	public void test1() {
		d=new Division(4, 0);
		int r=d.dividir();
		assertTrue(r==0);
	}

}