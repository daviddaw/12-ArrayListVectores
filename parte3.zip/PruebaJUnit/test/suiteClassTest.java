import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import test1.pp1;
import test1.testProducto;




@RunWith(Suite.class)
@SuiteClasses({pp1.class,testProducto.class})

public class suiteClassTest {

	/*@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}
*/
}
