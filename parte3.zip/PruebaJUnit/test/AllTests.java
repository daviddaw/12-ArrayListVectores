
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import test1.pp1;
import test1.testProducto;
import test1.testDivision;



@RunWith(Suite.class)
@SuiteClasses({pp1.class, testProducto.class, testDivision.class})


public class AllTests {

}
