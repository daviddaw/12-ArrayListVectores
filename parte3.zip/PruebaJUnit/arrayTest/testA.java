import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import arrayPruebaJU.Array;

public class testA {

	private Array arrayP;
	
	
	@Before
	public  void setUp() throws Exception {
		int [] array= new int[3];
		array[0]=5;
		array[1]=2;
		array[2]=9;
		
		arrayP= new Array(array);
		
	}
	
	
	

	@Test
	public void testOrdenar() {

		int [] array2= new int[3];
		array2[0]=2;
		array2[1]=5;
		array2[2]=9;
		
		
		arrayP.ordenar();
	
		assertArrayEquals(arrayP.getArray(), array2);
	
	}

	
	
	@Test
	public void testMinimo() {
		
		int min=2;
		
		assertTrue(arrayP.minimo()==min);
		
		
	}
	
	@Test 
	public void testInvertir() {
		
		int [] array2= new int[3];
		array2[0]=9; 
		array2[1]=2; 
		array2[2]=5; 
		
		
		 Array invertirP=arrayP.invertir();
		
		assertArrayEquals(invertirP .getArray(), array2);
	}
	
	
	
}
