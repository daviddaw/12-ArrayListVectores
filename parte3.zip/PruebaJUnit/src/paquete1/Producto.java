package paquete1;

public class Producto {
	private int a;
	private int b;
	
	public Producto (int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	public int multiplicar (){
		return a*b;
	}
}
