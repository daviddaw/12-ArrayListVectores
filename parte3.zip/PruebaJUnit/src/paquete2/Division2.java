package paquete2;

public class Division2 {
	private int a;
	private int b;
	
	public Division2(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int dividir () throws Exception{
		int cociente=Integer.MIN_VALUE;
		if (b==0)
			throw new Exception("Imposible dividir por 0");
		else
			cociente=a/b;
		return cociente;
	}
		
}
