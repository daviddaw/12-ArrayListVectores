package paquete2;

public class Division {
	private int a;
	private int b;
	
	public Division(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int dividir(){
		int cociente=Integer.MIN_VALUE;
		if (b==0)
			System.out.println("Imposible dividir por 0");
		else
			cociente=a/b;
		return cociente;
	}
		
}


