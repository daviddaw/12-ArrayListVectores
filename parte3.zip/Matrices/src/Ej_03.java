
public class Ej_03 {

	public static void main(String[] args) {
		/*
		 * 3.	Cargar una tabla de 10x10 con enteros entre 1 y 9 de forma aleatoria. 
		 * 		Sumar filas y sumar columnas visualizando los  resultados por pantalla.
		 */

		 int [][] matriz = new int [5][5];
		 int sumaf; 
		 int sumac;
		 
		 
		 for(int i=0; i<matriz.length;i++) {
			 for(int j=0;j<matriz.length;j++) 
				matriz[i][j]=(int)(Math.random()*9+1);	
			 	 
		 }

			 for(int i=0; i<matriz.length;i++) {
				 System.out.println(" ");
				 for(int j=0;j<matriz.length;j++) 
					System.out.print(matriz[i][j]+ " ");
		 }
			 System.out.println(" ");
			 
			 System.out.println("\n SUMA FILAS: ");
			 
			 for(int i=0; i<matriz.length; i++) {
				 sumaf=0;
			 	for(int j=0; j<matriz[i].length; j++)
			 		sumaf+=matriz[i][j];
			 	System.out.println("Suma de la fila "+(i+1)+" es "+ sumaf);
			 }
			 
			 
			 System.out.println("\n SUMA COLUMNAS: ");
			 
			 for(int i=0; i<matriz.length; i++) {
				 sumac=0; 
				 for(int j=0; j<matriz.length; j++)
					 sumac+=matriz[j][i];
				 System.out.println("Suma de la columna "+(i+1)+" es "+ sumac);
			 }
			
	}

}
