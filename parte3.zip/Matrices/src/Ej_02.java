
public class Ej_02 {

	public static void main(String[] args) {
		
		int diagonal [][]= new int [5][5];
		
			for(int i=0; i<diagonal.length; i++) {
				diagonal[i][i]=1;
			}
		
			
			for(int i=0; i<diagonal.length; i++) {
				System.out.println(" ");
				for(int j=0; j<diagonal.length; j++)
					System.out.print(diagonal[i][j]+" ");
			}
			
	}

}
