
public class Ej_05 {

	public static void main(String[] args) {
		// 5.	Cargar una tabla de 30x5 en memoria con las notas de 30 alumnos en 5 asignaturas. 
		//Calcular y mostrar: nota m�xima, nota media, media por alumno y media por asignatura. 


		int [][] alumnasig= new int[6][5];
		int almax=0,  acumulador=0;; 
		double almed=0;
		for(int i=0; i<alumnasig.length; i++)
			for(int j=0; j<alumnasig[i].length; j++)
				alumnasig[i][j]=(int)(Math.random()*10+1);


		for (int i=0; i<alumnasig.length; i++) {
			System.out.println("");
			for(int j=0; j<alumnasig[i].length; j++)
				System.out.print(alumnasig[i][j]+" ");
			
		}
		
		System.out.println(" ");
		
		
		System.out.println(" NOTA MAXIMA Y MEDIA POR ALUMNO: ");
		
		for(int i=0; i<alumnasig.length; i++) {
			almax=0; acumulador=0; almed=0;
			for(int j=0; j<alumnasig[i].length; j++) {
				acumulador+=alumnasig[i][j];
				almed=acumulador/5;
				if(alumnasig[i][j]>almax)
					almax=alumnasig[i][j];
			}
			
		
		 	System.out.println("\nLa nota maxima del alumno "+(i+1)+" es "+ almax);
		 	System.out.println("La nota media del alumno "+(i+1)+" es "+ almed);
					
		}
		
		for(int i=0; i<alumnasig[0].length; i++) {
			almax=0; acumulador=0; almed=0;
			for(int j=0; j<alumnasig.length; j++) {
				acumulador+=alumnasig[j][i];
				almed=acumulador/6;
				if(alumnasig[j][i]>almax)
					almax=alumnasig[j][i];
			}
			System.out.println("\nLa nota maxima del alumno "+(i+1)+" es "+ almax);
		 	System.out.println("La nota media del alumno "+(i+1)+" es "+ almed);
					
		}
		
		
		//FALTA MEDIA DE TODO
		
	}
}
