
public class Ej_04 {

	public static void main(String[] args) {
		// 4.	Cargar una matriz de 5x3, trasponerla y mostrar el resultado (la carga se puede hacer por teclado o de forma aleatoria)
		
		int matriz[][] = new int [5][3];
		int traspuesta[][] = new int [3][5];
		
		//CARGAR
		for(int i=0; i<matriz.length; i++) {
			for(int j=0; j<matriz[i].length; j++)
				matriz[i][j]=(int)(Math.random()*9+1);
		}
		
		
		//VER
		for (int i=0; i<matriz.length; i++) {
			System.out.println("");
			for(int j=0; j<matriz[i].length; j++)
				System.out.print(matriz[i][j]+" ");
			
		}
		
		
		//TRASPONER
		for(int i=0; i<matriz.length; i++)
			for(int j=0; j<matriz[i].length; j++)
				traspuesta[j][i]=matriz[i][j];
		
		
		
		//VERT
		System.out.println(" ");
		for (int i=0; i<traspuesta.length; i++) {
			System.out.println("");
			for(int j=0; j<traspuesta[i].length; j++)
				System.out.print(traspuesta[i][j]+" ");
		}
		
	}

}
