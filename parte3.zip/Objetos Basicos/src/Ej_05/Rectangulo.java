package Ej_05;

public class Rectangulo {

	private Punto puntoizq; //esquina inferior izquierda
	private Punto puntoder; //esquina superior derecha
	
	
	
	public Rectangulo() {
		this.puntoizq.setX(0);
		this.puntoizq.setY(0);
		this.puntoder.setX(1);
		this.puntoder.setY(1);
	}
	
	public Rectangulo(Punto esqizq, Punto esqder) {
		puntoizq=esqizq;
		puntoder=esqder;
	}
	
	public Rectangulo(Punto esqizq, double ancho, double alto) {
		puntoder.setX(alto);
		puntoder.setY(ancho);
	}
	
	
	public String visualizar() {
		return "La esquina inferior izquierda esta en "+puntoizq.getX()+","+puntoizq.getY()+"y la superior derecha en"+puntoder.getX()+","+puntoder.getY();
	}
	
	
	
	public double base(Rectangulo rectangulo) {
		double base;
		base=puntoder.getX()-puntoizq.getX();
		return base;
	}
	
	
	
	public double altura(Rectangulo rectangulo) {
		double altura;
		altura=puntoder.getY()-puntoizq.getY();
		return altura;
	}
	
	
	
	public double area(Rectangulo rectangulo) {
		double area;
		area=(base(rectangulo)*altura(rectangulo));
		return area;
	}
	
	
	
	public double perimetro(Rectangulo rectangulo) {
		double perimetro;
		perimetro=(2*base(rectangulo)) + (2*altura(rectangulo));
		return perimetro;
	}
	
	
	
	
	
	
	
}
