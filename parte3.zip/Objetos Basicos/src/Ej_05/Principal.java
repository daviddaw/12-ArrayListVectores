package Ej_05;

import Ej_01.LeerTeclado;


public class Principal {

	public static void main(String[] args) {
		
		
		System.out.println("Introduce X e Y del punto 1");
		Punto p1 = new Punto(LeerTeclado.readDouble(), LeerTeclado.readDouble());
		
		System.out.println("Introduce X e Y del punto 2");
		Punto p2 = new Punto(LeerTeclado.readDouble(), LeerTeclado.readDouble());
		
		System.out.println("Introduce X e Y del punto 3");
		Punto p3 = new Punto(LeerTeclado.readDouble(), LeerTeclado.readDouble());
		
		System.out.println("La distancia del punto 1 y 2 es de: " + p1.distancia(p2));
		System.out.println("La distancia del punto 2 y 3 es de: " + p2.distancia(p3));
		System.out.println("La distancia del punto 3 y 1 es de: " + p3.distancia(p1));
		
		
		
		System.out.println("Se ha creado un rectangulo con los puntos p1: "+p1.getX()+","+p1.getY() + " y p2: "+p2.getX()+","+p2.getY() );
		Rectangulo rec1 = new Rectangulo(p1, p2);
		System.out.println("La base es "+rec1.base(rec1));
		System.out.println("La altura es "+rec1.altura(rec1));
		System.out.println("El  area es "+rec1.area(rec1));
		System.out.println("El perimetro es "+rec1.perimetro(rec1));
	
	}

}
