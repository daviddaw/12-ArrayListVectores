package Ej_05;

public class Punto {

	private double x;
	private double y;
	
	public Punto() {
		
	}
	
	public Punto(double x, double y) {
		this.x=x;
		this.y=y;
	}

	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	public double distancia(Punto p1) {
		//return Math.sqrt(Math.pow((x-p1.x),2)+ Math.pow((y-p1.y),2)); los 2 valen 
		return Math.sqrt(Math.pow((this.x-p1.getX()),2)+ Math.pow((this.y-p1.getY()),2));
	}
	
	
	public void desplazar(double a, double b) {
		this.x+=a;
		this.y+=b;
	}
	
	
	
}
