package Ej_03;

public class Principal {

	public static void main(String[] args) {
		//Posicion opuesto;
		Posicion p1 = new Posicion(4, 6);
		System.out.println(p1.getXY(p1));
		
		System.out.println("incremento x+2 y+3");
		p1.incXY(2, 3);
		System.out.println(p1.getXY(p1));
		
		System.out.println("decremento x-1 y-1");
		p1.decXY(1, 1);
		System.out.println(p1.getXY(p1));
		p1.recta(p1);
		
		//opuesto=p1.opuestoXY(p1);
		//p1.recta(opuesto);
	}

}
