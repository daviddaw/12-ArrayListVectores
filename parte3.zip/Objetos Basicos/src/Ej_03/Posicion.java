package Ej_03;

public class Posicion {

	private int x;
	private int y;
	
	public Posicion() {
		
	}
	
	public Posicion(int x, int y) {
		this.x=x;
		this.y=y;
	}
	

	public Posicion(Posicion p1){
		this.x=p1.x;
		this.y=p1.y;
		
	}
	
	public void setXY(int x, int y) {
		this.x=x;
		this.y=y;
	}
	
	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public String getXY(Posicion p1) {
		return "x="+ x +" y=" +y;
	}
	
	
	public void decXY(int x,int y) {
		this.x-=x;
		this.y-=y;
	}
	
	public void incXY(int x, int y) {
		this.x+=x;
		this.y+=y;
	}
	
	
	public  void recta(Posicion puntorecta) {
		double m;
		m = (double)(puntorecta.getY()-y) / (double)(puntorecta.getX()-x);
		System.out.println("y-"+y+"="+m+"(x-"+x+")");
		
	}
	
	public Posicion opuestoXY(Posicion posicion) {
		Posicion opuesto = new Posicion(-(posicion.x), -(posicion.y));
 		return opuesto;
		
	}
	
	
	
}
