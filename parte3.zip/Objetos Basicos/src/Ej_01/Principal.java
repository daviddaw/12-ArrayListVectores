package Ej_01;

public class Principal {

	public static void main(String[] args) {
		
		double l;
		System.out.println("Introduce el lado del Triangulo 1");
		l=LeerTeclado.readDouble();
		
		TrianguloEquilatero t1 = new TrianguloEquilatero(l);
		System.out.println(t1.toString());
		
		
		System.out.println("Introduce el lado del Triangulo 2");
		l=LeerTeclado.readDouble();
		
		
		TrianguloEquilatero t2 = new TrianguloEquilatero(l);
		System.out.println(t2.toString());
		
		
		System.out.println("Introduce el nuevo lado para el Triangulo 2");
		l=LeerTeclado.readDouble();
		t2.setLado(l);
		System.out.println("Los nuevos valores del Triangulo 2 son: ");
		System.out.println(t2.toString());
		
		
		if(t1.equals(t2))
			System.out.println("Los triangulos son iguales");
		else 
			System.out.println("Los triangulos no son iguales");

	}

}
