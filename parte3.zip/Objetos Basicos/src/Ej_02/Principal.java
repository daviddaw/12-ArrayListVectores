package Ej_02;

import Ej_01.LeerTeclado;

public class Principal {

	public static void main(String[] args) {
		
		String nom, col;
		double pre, inc;
		
		Articulo a1 = new Articulo("a1", "verde", 25);
		System.out.println(a1.toString());
		
	
		System.out.println("Introduce el nombre del Articulo 2");
		nom=LeerTeclado.readString();
		System.out.println("Introduce el color del Articulo 2");
		col=LeerTeclado.readString();
		System.out.println("Introduce el precio del Articulo 2");
		pre=LeerTeclado.readDouble();
		
		Articulo a2= new Articulo();
		a2.nombre=nom;
		a2.setColor(col);
		a2.setPrecio(pre);
		System.out.println(a2.toString());
		
		
		System.out.println("Introduce el precio del Articulo 3");
		pre=LeerTeclado.readDouble();
		Articulo a3 = new Articulo("a3", "azul");
		a3.setPrecio(pre);
		System.out.println(a3.toString());
		
		
		
		System.out.println("Introduce un nuevo nombre para a1");
		nom=LeerTeclado.readString();
		System.out.println("Introduce un nuevo color para a1");
		col=LeerTeclado.readString();
	
		a1.nombre=nom;
		a1.setColor(col);
		System.out.println(a1.toString());
	
		System.out.println("Introduce la cantidad de incremento para a2");
		inc=LeerTeclado.readDouble();
		a2.incrementarPrecio(inc);
		System.out.println(a2.toString());
		
		
		System.out.println("a1 con rebaja");
		a1.rebajarPrecio();
		System.out.println(a1.toString());
		
		if(a1.equals(a2))
			System.out.println("Los articulos son iguales");
		else
			System.out.println("Los articulos no son iguales");
		
		
		
	}
	
		
	

}
