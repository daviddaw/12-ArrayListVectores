package Ej_02;

public class Articulo {

	private static int c; //------>autonumerico
	public String nombre;
	private String color;
	private double precio;
	private int  codigo;
	
	
	public Articulo(){
		c++;
		codigo=c;
	}
	
	public Articulo(String nombre, String color, double precio) {
		c++;
		codigo=c;
		this.nombre=nombre;
		this.color=color;
		this.precio=precio;
		
	}
	
	public Articulo(String nombre, String color) {
		c++;
		codigo=c;
		this.nombre=nombre;
		this.color=color;
	}

	public int getCodigo() {
		return codigo;
	}


	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	
	public double incrementarPrecio(double cantidad) {
		precio=precio+cantidad;
		return  precio;
	}


	public double rebajarPrecio() {
		return precio*=0.90;

	}
	
	
	public boolean equals(Articulo otroart) {
		return this.nombre==otroart.nombre && this.color==otroart.color && this.precio==otroart.precio;
			
			
	}
	
	public String toString() {
		return "Articulo "+codigo+" [nombre="  + nombre + ", color=" + color + ", precio=" + precio + 
				 "]";
	}

	
}