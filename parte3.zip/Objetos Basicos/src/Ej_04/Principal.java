package Ej_04;

public class Principal {

	public static void main(String[] args) {
		
		Autor a1 = new Autor("pablo", "espa�a", 2001);
		System.out.println(a1.toString());
		
		
		Autor a2 = new Autor("pedro", "chile", 2009);
		System.out.println(a2.toString());
		
		if(a1.equals(a2))
			System.out.println("Son los mismos autores");
		else
			System.out.println("No son los mismos autores");
		
		
		Libro l1 = new Libro("R123", "el lago", a1);
		System.out.println(l1.toString());
		
		Libro l2 = new Libro("R345", "la isla", a2);
		System.out.println(l2.toString());
		
		
		if(l1.equals(l2))
			System.out.println("El libro es el mismo");
		else
			System.out.println("No son los mismos libros");
		
		
		System.out.println();
		
		
		l1.prestarLibro();
		System.out.println(l1.toString());
		//l1.prestarLibro();
		
		System.out.println();
		
		l1.devolverLibro();
		System.out.println(l1.toString());
		//l1.devolverLibro();
	}

}
