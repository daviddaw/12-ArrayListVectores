package Ej_04;

public class Autor {


	private String nombre;
	private String nacionalidad;
	private int anio;
	private int anio_def;
	
	
	public Autor() {
		
	}
	
	
	public Autor(String nombre, String nacionalidad, int anio) {
		this.nombre=nombre;
		this.nacionalidad=nacionalidad;
		this.anio=anio;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getNacionalidad() {
		return nacionalidad;
	}


	public void setNacionalidad(String nacionalidad) {
		this.nacionalidad = nacionalidad;
	}


	public int getAnio() {
		return anio;
	}


	public void setAnio(int anio) {
		this.anio = anio;
	}


	public int getAnio_def() {
		return anio_def;
	}


	public void fallecer(int anio) {
		this.anio_def=anio;
	}


	public boolean equals(Autor otroautor) {
		return this.nombre==otroautor.nombre && this.nacionalidad==otroautor.nacionalidad && this.anio==otroautor.anio;
	}
	
	
	
	@Override
	public String toString() {
		return "Autor [nombre=" + nombre + ", nacionalidad=" + nacionalidad + ", anio=" + anio + ", anio_def="
				+ anio_def + "]";
	}
	
	
	
	
	}


