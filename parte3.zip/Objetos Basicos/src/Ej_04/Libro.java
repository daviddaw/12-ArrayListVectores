package Ej_04;

public class Libro {
	
	private String isbn;
	private String titulo;
	private boolean prestado;
	Autor autor1;

	public Libro(String isbn, String titulo, Autor autor1) {
		this.isbn=isbn;
		this.titulo=titulo;
		this.autor1=autor1;
		prestado=false;
	}


	public String getIsbn() {
		return isbn;
	}



	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}



	public String getTitulo() {
		return titulo;
	}



	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}



	public Autor getAutor1() {
		return autor1;
	}



	public void setAutor1(Autor autor1) {
		this.autor1 = autor1;
	}


	public boolean isPrestado() {
		return prestado;
	}

	public void setPrestado(boolean prestado) {
		this.prestado = prestado;
	}
	

	public void prestarLibro() {
		if(prestado==true)
			System.out.println("El libro ya esta prestado");
		else
			System.out.println("Se ha prestado el libro: ");
				prestado=true;
	}
	
	public void devolverLibro() {
		if(prestado==false)
			System.out.println("El libro no esta prestado");
		else 
			System.out.println("Se ha devuelto el libro: ");
				prestado=false;
	}
	
	
	public boolean equals(Libro otrolibro) {
		return this.isbn==otrolibro.isbn && this.titulo==otrolibro.titulo && this.autor1==otrolibro.autor1;
	}


	@Override
	public String toString() {
		return "Libro [isbn=" + isbn + ", titulo=" + titulo + ", prestado=" + prestado + ", autor1=" + autor1 + "]";
	}
	
	

	
}
