package Ej_06;

public class Principal {

	public static void main(String[] args) {
		Jugador jug1 = new Jugador("pedro", 2);
		Jugador jug2 = new Jugador("pablo", 5);
		
		System.out.println(jug1.toString());
		System.out.println(jug2.toString());
		
		Partido p1 = new Partido(jug1, jug2);
		p1.jugar();
		
	}

}
