package Ej_06;

public class Jugador {

	private String nombre;
	private double puntuacion;
	
	public Jugador(){
		
	}
	
	
	public Jugador(String nombre, double puntuacion){
		this.nombre=nombre;
		this.puntuacion=puntuacion;
	}
	
	
	public String getNombre(){
		return nombre;
	}
	
	public double getPuntuacion(){
		return puntuacion;
	}
	
	
	public void setPuntuacion(double puntuacion){
		this.puntuacion=puntuacion;
	}

	public void incPuntuacion(){
		puntuacion++;
	}
	
	public String toString() {
		return "Jugador [nombre=" + nombre + ", puntuacion=" + puntuacion + "]";
	}
	
	
	
	
	
	
	
}
