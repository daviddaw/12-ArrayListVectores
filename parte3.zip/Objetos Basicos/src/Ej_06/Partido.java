package Ej_06;

public class Partido {

	private Jugador jug1;
	private Jugador jug2;
	
	public Partido(Jugador jug1, Jugador jug2){
		this.jug1=jug1;
		this.jug2=jug2;
		//this.ganador=null;
	}
	
	
	public Jugador getJugador1(){
		return jug1;
	}
	
	
	public Jugador getJugador2(){
		return jug2;
	}
	
	
	public Jugador ganador(){
		double puntjug1;
		double puntjug2;
		do{
			puntjug1=Math.random()*jug1.getPuntuacion();
			puntjug2=Math.random()*jug2.getPuntuacion();

		}while(puntjug1==puntjug2);

		System.out.println("Puntos del jugador 1 en el partido "+puntjug1);
		System.out.println("Puntos del jugador 2 en el partido "+puntjug2);
		
		if(jug1.getPuntuacion()<jug2.getPuntuacion())
			return jug1;
		else 
			return jug2;
	}
	
	
	public void jugar(){
		Jugador gana=ganador();
		gana.incPuntuacion();
		System.out.println("El ganador es "+ gana.getNombre());
		System.out.println("Su nueva puntuacuon en la ATP es "+gana.getPuntuacion());
	}
	
	
	
}
