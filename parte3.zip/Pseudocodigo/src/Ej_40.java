
public class Ej_40 {

	public static void main(String[] args) {
		//40.	Algoritmo que calcule todos los n�meros perfectos de 1 a 1000
		int n,suma=0; 
		//System.out.println("Introduce un numero");
		//n=LeerTeclado.readInteger();
		for(int o=1; o<=50; o++) {
			for(int i=1;i<o;i++) {
				if(o%i==0)
					suma=suma+i;
			
			if(suma==o)
				System.out.println("as"+o);
			//else
			//	System.out.println("no es perfecto");
}
		}
	}

}
