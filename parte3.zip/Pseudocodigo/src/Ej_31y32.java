
public class Ej_31y32 {

	public static void main(String[] args) {
		// 31.	Algoritmo que dado un n� N y una serie de n�meros terminada en 0
		//indique si el n�mero N se encuentra en la serie.
		//32.	Idem contando las veces que se repite N en la serie.

		int n, m, c=0; 
		boolean encontrado=false;
		System.out.println("Introduce el numero que deseas buscar");
		m=LeerTeclado.readInteger();
		System.out.println("Introduce una serie de numeros");
		n=LeerTeclado.readInteger(); 

		while(n!=0){
			if(n==m){
				encontrado=true;
				c++;
			}
			n=LeerTeclado.readInteger(); 
		}
		if(encontrado==true)
			System.out.println("el numero "+m+" esta en la serie y se repite "+c+ " veces" );
		else 
			System.out.println("El numero "+m+" no esta en la serie" );
	}

}
