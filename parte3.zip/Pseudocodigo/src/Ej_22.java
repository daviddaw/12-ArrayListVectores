
public class Ej_22 {

	public static void main(String[] args) {
		// 22.	Aceptar n�meros por teclado hasta que la suma de todos ellos sea superior a 1000
		int n, suma=0; 
		
		do {
			System.out.println("Intoduce un numero");
			n=LeerTeclado.readInteger();
			suma+=n;
		}while (suma<=1000);
		System.out.println("la suma es "+ suma);
	}


}
