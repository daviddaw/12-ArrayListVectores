
public class Ej_08 {

	public static void main(String[] args) {
		// 8.	Algoritmo que introduzca un n� de 1 a 7 y visualice el d�a de la semana que representa (Lunes, martes, etc.).

		int a;

		do {
			System.out.println("introduce un numero del 1 al 7");
			a=LeerTeclado.readInteger();
		} 
		while(a<1 || a>7);

		switch(a) {
		case 1: System.out.println("Lunes"); 
		break;
		case 2: System.out.println("Martes"); 
		break;
		case 3: System.out.println("Miercoles"); 
		break;
		case 4: System.out.println("Jueves"); 
		break;
		case 5: System.out.println("Viernes"); 
		break;
		case 6: System.out.println("S�bado"); 
		break;
		case 7: System.out.println("Domingo"); 
		break;
		}

	}

}
