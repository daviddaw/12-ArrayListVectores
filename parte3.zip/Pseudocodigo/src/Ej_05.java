
public class Ej_05 {

	public static void main(String[] args) {
		// 5.	Algoritmo que decida si un n�mero introducido por teclado es par o impar.

		System.out.println("introduce un numero");
		int a;
		a=LeerTeclado.readInteger();
		if(a%2==0)
			System.out.println("el numero es par");
		else 
			System.out.println("el numero es impar");
	}

}
