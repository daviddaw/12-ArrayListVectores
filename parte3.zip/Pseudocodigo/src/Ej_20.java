
public class Ej_20 {

	public static void main(String[] args) {
		// 20.	Imprimir la suma de los m�ltiplos de 2 desde el 8 al 400

		int suma=0;
		for(int i=8; i<=400; i+=2)
			suma+=i;
		
		System.out.println(suma);
	}

}
