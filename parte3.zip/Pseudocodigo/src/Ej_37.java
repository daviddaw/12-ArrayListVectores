
public class Ej_37 {

	public static void main(String[] args) {
		// 37.	Algoritmo que lee tres n�meros, los visualiza en orden creciente e indica si fueron introducidos en ese orden.
		
		
		int a,b,c,aux1=0,aux2,aux3;
		System.out.println("Introduce 3 Numeros");
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();
		c=LeerTeclado.readInteger();
		if(a<b && b<c)
			System.out.println("Fueron introducidos en orden creciente");
		
		else {
			if(b<a) {
				aux1=a;
				a=b;
				b=aux1;
			}
			if(c<a) {
				aux2=a;
				a=c;
				c=aux2;
			}

			if(c<b) {
				aux3=c;
				c=b;
				b=aux3;
			}
			System.out.println(a+"<"+b+"<"+c);
		}

		
	}

}
