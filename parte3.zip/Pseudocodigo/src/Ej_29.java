
public class Ej_29 {

	public static void main(String[] args) {
		// 29.	Obtener las tablas de multiplicar de los n�meros del 1 al 10

		int mult=0;
		for(int i=1; i<=10; i++){
			for(int o=1; o<=10; o++){
				mult=i*o;
				System.out.println(i+"x"+o+"="+mult);
			}
		}
	}
}
