
public class Ej_17 {

	public static void main(String[] args) {
		// 17.	Calcular el factorial de un n�mero
		int n, fac=1;
		System.out.println("Introduce un numero");
	    n=LeerTeclado.readInteger();
	    for(int i=1; i<=n; i++)
	    	fac*=i;
	    System.out.println("El factorial de "+n+ " es "+ fac);
	    
	
	
	
	}

}
