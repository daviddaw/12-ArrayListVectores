
public class Ej_28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//28.	Algoritmo que dada una serie de n� terminada en 0 indique si ha habido alg�n negativo
		

		int n; 
		boolean neg=false;
		System.out.println("Intruce numeros, 0 para terminar");
		n=LeerTeclado.readInteger();
		while(n!=0) {
			if(n<0) 
				neg=true;
			n=LeerTeclado.readInteger();
		}
		if(neg==true)
			System.out.println("hay algun negativo");
		else
			System.out.println("no hay ningun negativo");


	}
}
