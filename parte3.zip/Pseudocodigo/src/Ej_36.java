
public class Ej_36 {

	public static void main(String[] args) {
		// 36.	Visualizar la suma de los N primeros n�meros primos
		int n, i, m=3, y, c=2, suma=2;
		boolean primo;
		do {
			System.out.println("Introduce el numero de primos que desea.");
			n=LeerTeclado.readInteger();
		} while (n<1);
			for (i=1; i<n; i++){															
				do{																	
					primo=true;															
					for (y=2; y<=m/2; y++){												
						if (m%y==0){														
							primo=false;													
						}																	
					}																		
					if (primo)																				
						suma=suma+m;																					
					m=m+2;																								
				}while (!primo);																			
				c=c+1;																										
			}																																		
			System.out.println("La suma de los "+n+" numeros primos es "+suma);
		
		

	}

}
