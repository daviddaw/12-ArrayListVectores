
public class Ej_24 {

	public static void main(String[] args) {
		// 24.	Algoritmo que calcule todos los divisores de un n� N

		int n; 
		System.out.println("Introduce un numero");
		n=LeerTeclado.readInteger();
		System.out.println("sus divisores son:");
		for(int i=1; i<=n; i++)
			if(n%i==0)
				
				System.out.println(i);
	}

}
