
public class Ej_33 {

	public static void main(String[] args) {
		// 33.	Dado un n�mero, decir si es primo 

		int n; 
		boolean primo=true;
		System.out.println("Introduce un numero");
		n=LeerTeclado.readInteger(); 
		for(int i=1; i<=n/2; i++){
			if(n%2==0)
				primo=false;
		}
		if(primo==true)
			System.out.println("es primo");
		else 
			System.out.println("no es primo");
	}


}
