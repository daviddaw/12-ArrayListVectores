
public class Ej_14 {

	public static void main(String[] args) {
		// Calcular la suma de n�meros hasta que se teclee un 0      14.	Idem la media

		int n, suma=0, c=0;
		double media=0;
		System.out.println("Introduce una serie de numeros, 0 para terminar");
		n=LeerTeclado.readInteger();

		while(n!=0) {
			suma+=n;
			n=LeerTeclado.readInteger();
			c++;
		}
		media=(double)suma/c;
		System.out.println("La suma total es "+suma);
		System.out.println("La media es "+media);

	}


}
