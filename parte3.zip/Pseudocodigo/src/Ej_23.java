
public class Ej_23 {

	public static void main(String[] args) {
		//23.	Dada la ecuaci�n y= x3+ 5*x2-2*x, visualizar el valor de y para los valores de x m�ltiplos de 5 desde el 10 hasta el 75. 
		
		int y=0;
		System.out.println("Ecuacion:y=x3+ 5*x2-2*x ");
		for(int i=5; i<=10; i+=5) {
			y=(i*3)+5*(i*2)-2*i;

			System.out.println("Resultado con x=" +i+ " "+y);
		}
	}

}
