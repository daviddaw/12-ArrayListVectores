
public class Ej_02 {

	public static void main(String[] args) {
		// 2.	Algoritmo que dado un radio calcule la longitud de su circunferencia y el �rea del c�rculo.
		
		double radio,longitud, area;
		System.out.println("Introduce un radio");
		radio=LeerTeclado.readDouble();
		area=Math.PI*Math.pow(radio, 2);
		longitud=2*Math.PI*radio;
		System.out.println("El area de la circunferencia es " +area);
		System.out.println("La longitud de la circunferencia es " +longitud);
	}

}
