
public class Ej_25 {

	public static void main(String[] args) {
		// 25.	Algoritmo que, dado un a�o, decida si es bisiesto o no: Es m�ltiplo de 4 Y o bien es m�ltiplo de 400 o no es m�ltiplo de 100

	}

}
