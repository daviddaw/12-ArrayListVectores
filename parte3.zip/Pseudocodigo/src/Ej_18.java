
public class Ej_18 {

	public static void main(String[] args) {
		// 18.	Algoritmo que calcule la suma de todos los n�meros comprendidos entre dos dados 
		int a,b,suma=0; 
		System.out.println("Introduce 2 n�meros");
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();
		for(int i=a; i<=b; i++)
			suma+=i;

		System.out.println("La suma de los numeros comprendidos entre "+a+" y " +b+" es "+suma);
	}

}
