
public class Ej_27 {

	public static void main(String[] args) {
		// 27.	Dados dos n�meros x, y  calcular por sumas sucesivas x * y.
		
		int x=0, y=0, suma=0; 
		System.out.println("introduce x e y");
		x=LeerTeclado.readInteger();
		y=LeerTeclado.readInteger();
		for(int i=1; i<=y; i++)
			suma=suma+x;
		System.out.println(suma);
	}

}
