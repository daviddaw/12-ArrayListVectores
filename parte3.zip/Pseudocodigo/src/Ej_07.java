
public class Ej_07 {

	public static void main(String[] args) {
		// 7.	Algoritmo que lea dos n�meros y decida si uno es divisor de otro.

		int a,b;

		System.out.println("Introduce 2 n�meros");
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();

		if (a%b==0)
			System.out.println(b+" es divisor de "+a);
		else
			if(b%a==0)
				System.out.println(a+ " es divisor de " +b);
			else 
				System.out.println("no son divisores");
	}

}
