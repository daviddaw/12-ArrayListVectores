
public class Ej_01 {

	public static void main(String[] args) {
		//1.	Algoritmo que dado dos n�meros calcule su suma, resta, producto y divisi�n e imprima el resultado.


		int a,b,sum,rest,mult;
		double div;

		System.out.println("introduce 2 numeros");
		a=LeerTeclado.readInteger();
		b=LeerTeclado.readInteger();
		sum=a+b;
		rest=a-b;
		mult=a*b;
		
		System.out.println(a+"+"+b+ "="+ sum );
		System.out.println(a+"-"+b+ "="+ rest );
		System.out.println(a+"*"+b+ "="+ mult );
		
		if(b<0) {
			div=(double)a/b;
			System.out.println(a+"/"+b+ "="+ div );
		}
		else System.out.println("no se puede dividir entre 0");

		

	}
	

}
