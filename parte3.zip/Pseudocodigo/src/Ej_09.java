
public class Ej_09 {

	public static void main(String[] args) {
		// 9.	Imprimir los n�meros del 1 al 100

		for (int i=1; i<=100; i++)
			System.out.println(i);
	}

}
