
public class Ej_13 {

	public static void main(String[] args) {
		// 13.	Calcular la suma de n�meros hasta que se teclee un 0
		
		int n, suma=0;
		System.out.println("Introduce una serie de numeros, 0 para terminar");
		n=LeerTeclado.readInteger();

		while(n!=0) {
			suma+=n;
			n=LeerTeclado.readInteger();
		}
		System.out.println("La suma total es "+suma);


	}

}
