
public class Ej_34 {

	public static void main(String[] args) {
		// 34.	Visualizar los N primeros n�meros primos.
		int n, i, m=3, y, c=2;
		boolean primo;
		do {
			System.out.println("Introduce el numero de primos que desea.");
			n=LeerTeclado.readInteger();
		} while (n<1);
		if (n>1) {
			System.out.println("El primer numero primo es 2");
			for (i=1; i<n; i++){																			

				do{
					primo=true;	
					for (y=2; y<=m/2; y++){

						if (m%y==0){
							primo=false;
						}
					}
					if (primo)
						System.out.println("El primo numero "+c+" es "+m);
					m=m+2;
				}while (!primo);
				c=c+1;
			}	

		}
		else System.out.println("El primer primo es 2");





	}

}