
public class Ej_35 {

	public static void main(String[] args) {
		// 35.	Visualizar los n�meros primos hasta el N.

		int c=0,n,x,i;
		boolean primo;
		System.out.println("Introduce el nuemro de primos que quieres");
		x=2;
		n=LeerTeclado.readInteger();
		while(c<n) {
			primo=true;
			i=2;
			while(i<=x/2 && primo==true) {
				if(x%i==0) 
					primo=false;
				i=i+1;
			}
			if(primo==true) {
				System.out.println(x);
				c=c+1;
			}
			x=x+1;
		}

	}

}
