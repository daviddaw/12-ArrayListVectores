
public class Ej_15 {

	public static void main(String[] args) {
		//15.	Imprimir los m�ltiplos de 3 hasta N
		int n; 
		System.out.println("Introduce un numero");
		n=LeerTeclado.readInteger();
		for(int i=3; i<=n; i+=3)
			System.out.println(i);
	}

}
