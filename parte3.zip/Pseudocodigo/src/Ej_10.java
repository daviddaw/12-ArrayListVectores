
public class Ej_10 {

	public static void main(String[] args) {
		//10.	Obtener la tabla de multiplicar de un n�mero entre 1 y 10 introducido por teclado

		int a;
		do {
			System.out.println("introduce un numero del 1 al 10");
			a=LeerTeclado.readInteger();
		} 
		while(a<1 || a>10);

		for (int i=1; i<=10; i++)
			System.out.println(a+"x"+i+"="+i*a);
	}
}
