
public class Ej_30 {

	public static void main(String[] args) {
		// 30.	Se introducen edades de 25 alumnos de una clase, imprimir la edad del m�s joven, 
		//la del mayor y la media de la clase

		int n, joven, mayor, suma=0;
		double media=0;

		System.out.println("introduce las edades de 25 alumnos");
		n=LeerTeclado.readInteger();
		joven=n;
		mayor=n;
		suma+=n;
		for(int i=1; i<=24; i++){
			n=LeerTeclado.readInteger();
			suma+=n;
			if(n<joven)
				joven=n; 
			if(n>mayor)
				mayor=n;	
		}
		System.out.println("El alumno mas joven tiene "+joven+ " a�o(s)");
		System.out.println("El alumno mayor tiene "+mayor+ " a�o(s)");
		media=(double)suma/25;
		System.out.println("La media de la clase es "+media);

	}

}
