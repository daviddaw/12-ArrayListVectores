
public class Ej_16 {

	public static void main(String[] args) {
		/*16.	Algoritmo que introduzca una nota de 0 a 10 y obtenga los siguientes resultados:
			a.	Entre 0 y 2: Muy deficiente
			b.	3 y 4: Insuficiente
			c.	5: Suficiente
			d.	6: Bien
			e.	7 y 8: Notable
			f.	9 y 10: Sobresaliente. */

		int a; 
		do {
			System.out.println("Introduce una nota del 0 al 10");
			a=LeerTeclado.readInteger();
		} 
		while(a<0 || a>10);
	
		switch(a) {
		case 0:
		case 1:
		case 2:System.out.println("Muy deficiente");
		break;
		case 3:
		case 4:System.out.println("Insuficiente");
		break;
		case 5:System.out.println("Suficiente");
		break;
		case 6:System.out.println("Bien");
		break;
		case 7:
		case 8:System.out.println("Notable");
		break;
		case 9:
		case 10:System.out.println("Sobresaliente");

		}
	}

}
