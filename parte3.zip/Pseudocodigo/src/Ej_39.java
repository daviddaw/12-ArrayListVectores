
public class Ej_39 {

	public static void main(String[] args) {
		// 39.	Algoritmo que dado un n�mero diga si es perfecto (cuando la suma de sus divisores excluido �l es igual a dicho n�mero)
		
		int n,suma=0; 
		System.out.println("Introduce un numero");
		n=LeerTeclado.readInteger();
		for(int i=1;i<n;i++)
			if(n%i==0)
				suma=suma+i;
	
		if(suma==n)
			System.out.println("el numero es perfecto");
		else
			System.out.println("no es perfecto");

	}

}
