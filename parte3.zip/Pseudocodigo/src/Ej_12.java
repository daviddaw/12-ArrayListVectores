
public class Ej_12 {

	public static void main(String[] args) {
		// 12.	Calcular el producto de los n�meros del 1 al 100

		int prod=1;
		for(int i=2; i<=100; i++)
			prod*=i;
		
		System.out.println("El producto de los 100 primeros n�meros es "+prod);
	}

}
