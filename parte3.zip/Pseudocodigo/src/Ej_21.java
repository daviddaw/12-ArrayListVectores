
public class Ej_21 {

	public static void main(String[] args) {
		// 21.	Pedir al usuario 10 n�meros enteros y decidir cu�ntos son pares y cu�ntos impares,
		//obtener la suma de los pares y la media aritm�tica de los impares.

		int cnum=0, n, cpar=0, cimpar=0, sumap=0, sumaimp=0; 
		double media;
		System.out.println("Introduce 10 numeros");
		n=LeerTeclado.readInteger();
		while(cnum<9) {
			if (n%2==0) {
				cpar++;
				sumap+=n;
			}
			else { 
				cimpar++;
				sumaimp=0;
			}
			n=LeerTeclado.readInteger();
			cnum++;

		}
		media=(double)sumaimp/cimpar;
		System.out.println("Hay "+cpar+" pares. Y su suma es "+ sumap);
		System.out.println("Hay "+cimpar+" impares. Y su media es "+ media);
	}

}
