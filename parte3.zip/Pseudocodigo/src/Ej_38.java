
public class Ej_38 {

	public static void main(String[] args) {
		// 38.	Algoritmo que determine cu�ntas cifras posee un n�mero entero positivo introducido por teclado

		int n,c=1;
		System.out.println("introduce un numero");
		n=LeerTeclado.readInteger();
		while(n>9) {
			n=n/10;
		c=c+1;
		}
		System.out.println("El numero tiene "+c+" cifras");
	}

}
