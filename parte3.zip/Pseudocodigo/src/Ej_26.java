
public class Ej_26 {

	public static void main(String[] args) {
		//TODO Auto-generated method stub
		// 26.	Visualizar los factoriales de los n�meros del 1 al 10.   //MIRAR


		int fac;
		for(int i=1; i<=10; i++) {
			fac=1;
			for(int o=i; o>=1; o--) 
				fac=fac*i;

			System.out.println(fac);
		}
	}

}
