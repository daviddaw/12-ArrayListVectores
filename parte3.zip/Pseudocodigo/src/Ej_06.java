
public class Ej_06 {

	public static void main(String[] args) {
		//6.	Algoritmo que decida si un n�mero es positivo, negativo o cero

		int n;

		System.out.println("Introduce un numero");
		n=LeerTeclado.readInteger();
		if (n>0)
			System.out.println("El numero es positivo");
		else
			if(n<0)
				System.out.println("El numeo es negativo");
			else
				System.out.println("El  numero es 0");

	}

}
