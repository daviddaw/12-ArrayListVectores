
public class Ej_19 {

	public static void main(String[] args) {
		// 19.	Algoritmo que calcule el valor m�nimo, m�ximo y medio de una serie de n�meros introducidos por teclado 
		//(la serie termina cuando se introduce un 0).

		int n,min,max,suma=0,c=0;
		double media;
		System.out.println("Introduce una serie de numeros, 0 para terminar");
		n=LeerTeclado.readInteger();
		min=n;
		max=n;
		while(n!=0) {
			if(n<min)
				min=n;
			else
				if(n>max)
					max=n;
			suma+=n;
			c++;
			n=LeerTeclado.readInteger();

		}
		media=(double)suma/c;
		System.out.println("El valor minimo es " +min);
		System.out.println("El valor maximo es " +max);
		System.out.println("La media es " +media);
	}

}
