
public class Ej_11 {

	public static void main(String[] args) {
		// 11.	Calcular la suma de los n�meros del 1 al 100
		int suma=0;
		for(int i=1; i<=100; i++)
			suma+=i;
		System.out.println("La suma de los 100 primeros n�meros es "+ suma);
	}

}
