import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class Jefes extends Empleados  {
	
	private static int c;
	private String codigoJ;
	
	
	private ArrayList<Obreros> listaObreros;
	
	
	public Jefes(String nombre, int edad, double sueldo) {
		super(nombre, edad , sueldo);
		c++;
		codigoJ="J"+c;
		listaObreros=new ArrayList<Obreros>();
	}


	public ArrayList<Obreros> getListaObreros() {
		return listaObreros;
	}


	public void setListaObreros(ArrayList<Obreros> listaObreros) {
		this.listaObreros = listaObreros;
	}


	public String getCodigoJ() {
		return codigoJ;
	}


	public void setCodigoJ(String codigoJ) {
		this.codigoJ = codigoJ;
	}



	private void writeObject(ObjectOutputStream out) throws IOException{
		out.defaultWriteObject();
		out.writeInt(c);
	}


	private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException{
		ois.defaultReadObject();
		c=ois.readInt();
	}

	
	
	@Override
	public String toString() {
		return super.toString()+ " Jefes [codigoJ=" + codigoJ + ", listaObreros=" + listaObreros.size()
				+ "]";
	}


	
	
	
	
	
	
	
	
	
	
}
