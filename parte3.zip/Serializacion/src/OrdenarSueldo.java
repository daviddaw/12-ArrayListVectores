import java.util.Comparator;

public class OrdenarSueldo implements Comparator<Empleados> {

	@Override
	public int compare(Empleados emp1, Empleados emp2) {
		
		return ((int)emp1.getSueldo())-((int)emp2.getSueldo());
	}
	

}
