


import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

@SuppressWarnings("serial")
public class Empresa implements Serializable {

	Scanner entrada= new Scanner(System.in);

	//Vector <Empleados> vectorEmp= new Vector<Empleados>();
	Map<String, Empleados>mapEmpleados=new HashMap<String, Empleados>();
	
	
	

	public Jefes buscarJefe(String codigo){
		Jefes auxJefe;
		/*for(int i=0; i<mapEmpleados.size(); i++){
			if(mapEmpleados.entrySet() instanceof Jefes){
				auxJefe=(Jefes)mapEmpleados.get(codigo);
				if(auxJefe.getCodigoJ().equalsIgnoreCase(codigo))
					return auxJefe;
			}*/
		for(String key : mapEmpleados.keySet()) {
			if(mapEmpleados.get(key) instanceof Jefes) {
				auxJefe=(Jefes)mapEmpleados.get(key);
				if(auxJefe.getCodigoJ().equalsIgnoreCase(codigo))
					return auxJefe;
			}
		}

		return null;
	}

	
	
	
	public Obreros buscarobrero(String codigo){
		Obreros auxObrero;
	/*	for(int i=0; i<vectorEmp.size(); i++){
			if(vectorEmp.elementAt(i) instanceof Obreros){
				auxObrero=(Obreros)vectorEmp.elementAt(i);
				if(auxObrero.getCodigoO().equalsIgnoreCase(codigo))
					return auxObrero;
			}*/
	
		for(String key : mapEmpleados.keySet()) {
			if(mapEmpleados.get(key) instanceof Obreros) {
				auxObrero=(Obreros)mapEmpleados.get(key);
				if(auxObrero.getCodigoO().equalsIgnoreCase(codigo))
					return auxObrero;
			}

		}
		return null;
	}



	public  void agregarEmp() {
		
		int n;
		Empleados emp;
		String nombre; 
		int edad;
		double sueldo;
		Jefes aux; 
		//boolean repetido=false;
		String codJefeOb;

		do{
		System.out.println("1. Jefe"
					   + "\n2. Obrero");
		n=entrada.nextInt();
		}while(n<0 || n>3);
		
		switch(n) {
		case 1:
			System.out.println("nombre");
			nombre=entrada.next();
			System.out.println("Introduce la edad");
			edad=entrada.nextInt();
			System.out.println("sueldo");
			sueldo=entrada.nextDouble();
			emp= new Jefes(nombre, edad, sueldo);	
			mapEmpleados.put(((Jefes) emp).getCodigoJ(), emp);
			

			/*for(int i=0; i<vectorEmp.size(); i++) {
				if(vectorEmp.elementAt(i) instanceof Jefes) {
					aux=(Jefes)vectorEmp.elementAt(i);
					if(aux.getNombre().equalsIgnoreCase(nombre)){
						repetido=true;
						System.out.println("El jefe indicado ya existe");
					}
			
				
					break;
				}

			}
			
			if(repetido==false){
				System.out.println("edad");
				edad=entrada.nextInt();
				System.out.println("sueldo");
				sueldo=entrada.nextDouble();
				emp= new Jefes(nombre, edad, sueldo);	
				vectorEmp.addElement(emp);//a�adimos el emp al vector
			}
			 */
			break;


		case 2:
		
			System.out.println("Codigo jefe");
			codJefeOb=entrada.next();
			aux=buscarJefe(codJefeOb);

			if(aux!=null) {
				System.out.println("nombre");
				nombre=entrada.next();
				System.out.println("edad");
				edad=entrada.nextInt();
				System.out.println("sueldo");
				sueldo=entrada.nextDouble();
				emp = new Obreros(nombre, edad, sueldo, aux);
				aux.getListaObreros().add((Obreros) emp);//a�adimos al arraylist del Jefe
				mapEmpleados.put(((Obreros) emp).getCodigoO(), emp);//a�adimos al vector 
			}
			else
				System.out.println("no existe un jefe con ese codigo");

		}
		
	}
	
	
	public void subirSueldo(double porcentaje){

		Empleados emp; 
		double sueldo, p;

		for(String key : mapEmpleados.keySet()){
			if(mapEmpleados.get(key) instanceof Jefes){
				emp=mapEmpleados.get(key);
				sueldo=emp.getSueldo();
				p=1+(porcentaje/100);
				sueldo=(sueldo*p)+120;
				emp.setSueldo(sueldo);
			}
			else
				if(mapEmpleados.get(key) instanceof Obreros) {
					emp=mapEmpleados.get(key);
					sueldo=emp.getSueldo();
					p=1+(porcentaje/100);
					sueldo=sueldo*p;
					emp.setSueldo(sueldo);
				}
		}
		
/*		for(int i=0; i<vectorEmp.size(); i++){
			if(vectorEmp.elementAt(i) instanceof Jefes){
				emp=vectorEmp.elementAt(i);
				sueldo=emp.getSueldo();
				p=1+(porcentaje/100);
				sueldo=(sueldo*p)+120;
				emp.setSueldo(sueldo);
			}
			else 
				if(vectorEmp.elementAt(i) instanceof Obreros){
				emp=vectorEmp.elementAt(i);
				sueldo=emp.getSueldo();
				p=1+(porcentaje/100);
				sueldo=sueldo*p;
				emp.setSueldo(sueldo);
			}
		}*/

	}



	public void listarObrerosJ(String codigoJ) {
		
		Jefes jefe; 
		
		
		jefe=buscarJefe(codigoJ);
		
		if(jefe!=null)
			for(int i=0; i<jefe.getListaObreros().size(); i++)
				System.out.println(jefe.getListaObreros().get(i).toString());
		else
			System.out.println("El jefe indicado no existe");

	}
	
	
	

	
	public void listarJefeO(String codigoO) {
		
		Obreros obrero;
		
		obrero=buscarobrero(codigoO);
		
		if(obrero!=null)
			System.out.println("Codigo "+obrero.getJefe().getCodigoJ()+" Nombre " +obrero.getJefe().getNombre());
		
	}

	
	
	public void listarEmpleados() {//cambiado maps
		
		/*for(int i=0; i<vecEmp.size(); i++)
			System.out.println(vecEmp.toString());*/
		
		for(String key : mapEmpleados.keySet()) {
			System.out.println(mapEmpleados.get(key));
			
			
		}
	}
	
 
	
	
	
	
	public void borrarEmpleado(String codigo) {
		
		
		Empleados emp;
		String resp;

	/*	for(int i=0; i<vectorEmp.size(); i++){
			if(vectorEmp.elementAt(i) instanceof Jefes){
				emp=buscarJefe(codigo);
				if(emp!= null) {
					System.out.println(emp.toString());
					System.out.println("Esta seguro de eliminar el Empleado: s/n");
					resp=entrada.next();
					if(resp.equalsIgnoreCase("s")) {
						for(int j=0; j<((Jefes)emp).getListaObreros().size(); j++) 
							((Jefes)emp).getListaObreros().get(j).setJefe(null);
					}
					vectorEmp.remove(emp);
				}	
			}
			
			else {
				if(vectorEmp.elementAt(i) instanceof Obreros){
					emp=buscarobrero(codigo);
					if(emp!=null) {
						System.out.println(emp.toString());
						System.out.println("Esta seguro de eliminar el Empleado: s/n");
						resp=entrada.next();
						if(resp.equalsIgnoreCase("s")) 
							((Obreros)emp).getJefe().getListaObreros().remove(emp);

						vectorEmp.remove(emp);
					}
				}
			}
			
		}*/
		
		for(String key : mapEmpleados.keySet()){
			if(mapEmpleados.get(key) instanceof Jefes){
				emp=buscarJefe(codigo);
				if(emp!= null) {
					System.out.println(emp.toString());
					System.out.println("Esta seguro de eliminar el Empleado: s/n");
					resp=entrada.next();
					if(resp.equalsIgnoreCase("s")) {
						for(int j=0; j<((Jefes)emp).getListaObreros().size(); j++) 
							((Jefes)emp).getListaObreros().get(j).setJefe(null);
					}
					mapEmpleados.remove(codigo);
				}	
			}

			else {
				if(mapEmpleados.get(key) instanceof Obreros){
					emp=buscarobrero(codigo);
					if(emp!=null) {
						System.out.println(emp.toString());
						System.out.println("Esta seguro de eliminar el Empleado: s/n");
						resp=entrada.next();
						if(resp.equalsIgnoreCase("s")) 
							//((Obreros)emp).getJefe().getListaObreros().remove(emp);
							
						mapEmpleados.remove(codigo);
					}
				}
			}

		}

	}

/*
	
	public void ordenarNombre() {
		Collections.sort(vectorEmp);
	}
	
	
	public void ordSuel() {
		Collections.sort(vectorEmp, new OrdenarSueldo());
	}


*/


	public void listarObrerosJIterator(String codigoJ) {

		Jefes jefe; 
		jefe=buscarJefe(codigoJ);

		Iterator<Obreros> it = jefe.getListaObreros().iterator();

		while(it.hasNext()) {
			Obreros o =  it.next();
			System.out.println(o.toString());
		}


	}
	/*public void sueldoMayor(){

		for(Empleados emp : vectorEmp)
			if(emp.getSueldo()>2000)
				System.out.println(emp.toString());


	}*/


	}
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	




	
	
	
	
	
	
	
	
	
	
	







