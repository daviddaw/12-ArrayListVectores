
public class Ej_11 {

	public static void main(String[] args) {
		// 11.	Escribir un programa que dado un n�mero N calcule los N primeros n�meros de la serie de Fibonacci usando recursividad:
		//a1=0
				//�	a2=1
				//�	an= an-1 + an-2
		int n; 
		System.out.println("Introduce cuantos nuemeros de la serie de Fibonacci quieres");
		n=LeerTeclado.readInteger();
		for(int i=0; i<n; i++)
			System.out.println(Fibo(i));
	}

	public static int Fibo(int n) {
		if(n==0)
			return 0;
		if(n==1)
			return 1;
		return Fibo(n-1)+Fibo(n-2);

	}

}
