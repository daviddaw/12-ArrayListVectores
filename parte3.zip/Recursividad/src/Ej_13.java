
public class Ej_13 {

	public static void main(String[] args) {
		//13.	Escribir un programa que dado un n� obtenga sus cifras en orden inverso usando recursividad (1� las unidades, luego las decenas, etc)

		
		int num;
		System.out.println("Introduce un numero.");
		num=LeerTeclado.readInteger();
	       System.out.println("Invertido = " + invertir(num, 0)); 
		
		
	}
	public static int invertir(int n, int m
			) {

		if (n==0) 
			return m;
		 else 
			return invertir(n / 10, m * 10 + n % 10);
		
		
	}

}
