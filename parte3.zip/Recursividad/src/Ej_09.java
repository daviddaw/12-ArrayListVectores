
public class Ej_09 {

	public static void main(String[] args) {
		// 9.	Escribir un m�todo que calcule el factorial de un n� usando recursividad.
		
		
		int n;
		System.out.println("Introduce un numero para calcular el factorial");
		n=LeerTeclado.readInteger();
		System.out.println(FacRec(n));
	}


	public static int FacRec(int n) {
		if(n==0)
			return 1;
		else 
			return n*FacRec(n-1);
	}

}
