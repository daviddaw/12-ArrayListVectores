

public class Ej_12 {

	public static void main(String[] args) {
		// 12.	Escribir un programa que pase un n� de decimal a binario usando recursividad:
		//�	N=4  =>  Generar� 100


		int n; 
		n=LeerTeclado.readInteger();
		Binario(n);

	}
	public static void Binario(int n) {
		if(n<2)
			System.out.print(n);

		else {
			Binario(n/2);
			System.out.print(n%2);
		}

	}

}
