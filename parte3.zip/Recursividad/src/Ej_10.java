
public class Ej_10 {

	public static void main(String[] args) {
		// 10.	Escribir un m�todo recursivo que reciba como par�metros una base a y un  exponente b y calcule la potencia por productos sucesivos:
		//�	ab  se calcular� multiplicando el n� a tantas veces como indique b.
		//�	Hay que tener en cuenta que:
		//	a0=1
		//	a-b=1/ab
		
		double a,b; 
		a=LeerTeclado.readDouble();
		b=LeerTeclado.readDouble();
		System.out.println(PotRec(a, b));


	}

	public static double PotRec(double a, double b) {
		if(b==0)
			return 1;
		else
			if(b<0)
				return 1/(a*PotRec(a, -b-1));
			else
				return a*PotRec(a, b-1);

	}

}
