package Ej_01_Tarjetero;

import java.util.*;

public class Principal {

	public static void main(String[] args) {

		Tarjetero tarjetero = new Tarjetero();

		Agenda agenda= new Agenda();

		
		
		//Tarjeta t1 = new Tarjeta("Alvarez Sanchez, Alicia", "612123123");

		tarjetero.getPilaTarjetas().push(new Tarjeta("Alvarez Sanchez, Alicia", "612123123"));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Garcia Jimenez, Alberto", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Perez Jimenez, Antonio", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Garcia Plazuelo, Juan", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Abrides Sainz, Mario", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Aaaandes Sainz, Mario", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Gallego Fuentes, Alba", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Gamcia Jimenez, Alberto", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Almodovar Sanchez, Alicia", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Ramos Sanchez, Alicia", "612123123" ));
		tarjetero.getPilaTarjetas().push(new Tarjeta("Alvarez Sanchez, Alicia", "612123123" ));

		
		//System.out.println(tarjetero.toString());
		Stack<Tarjeta>nuevoTarjetero = tarjetero.getPilaTarjetas();
		char inicial;
		Tarjeta tarjetaNtarjetero;
		
		
		while(!tarjetero.getPilaTarjetas().isEmpty()){
			tarjetaNtarjetero=nuevoTarjetero.pop();
			inicial=tarjetaNtarjetero.getAp_Nombre().charAt(0);
			agenda.getPaginas()[(int)inicial-65].getSortedSetTarjeta().add(tarjetaNtarjetero);
		}
			
		
		System.out.println(agenda.toString());
	
		
		/*		  
		char asd='A';
		System.out.println((int)asd);
*/
	}
}
