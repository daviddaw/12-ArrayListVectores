package Ej_01_Tarjetero;

import java.util.Arrays;

public class Agenda {

	private Pagina paginas[];
	
	
	public Agenda() {
		paginas= new Pagina[26];
		
		for(int i=0; i<paginas.length; i++)
			paginas[i]= new Pagina();
		
	}


	public Pagina[] getPaginas() {
		return paginas;
	}


	public void setPaginas(Pagina[] paginas) {
		this.paginas = paginas;
	}


	@Override
	public String toString() {
		return "Agenda [paginas=" + Arrays.toString(paginas) + "]";
	}
	
	
	
	
	
}
