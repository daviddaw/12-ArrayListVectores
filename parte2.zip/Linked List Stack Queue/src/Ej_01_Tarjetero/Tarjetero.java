package Ej_01_Tarjetero;

import java.util.Stack;

public class Tarjetero {

	
	private Stack<Tarjeta>pilaTarjetas;
	

	 
	public Tarjetero(){
		pilaTarjetas= new Stack<Tarjeta>();
	}


	public Stack<Tarjeta> getPilaTarjetas() {
		return pilaTarjetas;
	}


	public void setPilaTarjetas(Stack<Tarjeta> pilaTarjetas) {
		this.pilaTarjetas = pilaTarjetas;
	}


	@Override
	public String toString() {
		return "Tarjetero [pilaTarjetas=" + pilaTarjetas + "]";
	}
	
	
	
}
