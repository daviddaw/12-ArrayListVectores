package Ej_01_Tarjetero;

import java.util.LinkedList;
import java.util.TreeSet;

public class Pagina {
	
	//private LinkedList<Tarjeta>listaTarjetas;
	private TreeSet<Tarjeta>sortedSetTarjeta;
	private static int numL=65;
	private int c;
	
	 
	public Pagina() {
		//listaTarjetas=new LinkedList<>();
		sortedSetTarjeta=new TreeSet<Tarjeta>();
		c=numL;
		numL++;
	}
	
	/*
	public LinkedList<Tarjeta> getListaTarjetas() {
		return listaTarjetas;
	}
	public void setListaTarjetas(LinkedList<Tarjeta> listaTarjetas) {
		this.listaTarjetas = listaTarjetas;

}
*/
	

	public TreeSet<Tarjeta> getSortedSetTarjeta() {
		return sortedSetTarjeta;
	}

	public void setSortedSetTarjeta(TreeSet<Tarjeta> sortedSetTarjeta) {
		this.sortedSetTarjeta = sortedSetTarjeta;
	}
	

	public static int getNumL() {
		return numL;
	}



	public static void setNumL(int numL) {
		Pagina.numL = numL;
	}


	@Override
	public String toString() {
		return "\nPagina LETRA "+(char)c+" [listaTarjetas=" + /*listaTarjetas*/sortedSetTarjeta+ " ]";
	}

	
	
	


	
}