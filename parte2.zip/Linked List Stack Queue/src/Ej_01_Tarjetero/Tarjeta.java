package Ej_01_Tarjetero;

public class Tarjeta implements Comparable<Tarjeta>{

	private String ap_Nombre;
	private String tlf;
	
	
	
	public Tarjeta(String ap_Nombre, String tlf){
		this.ap_Nombre=ap_Nombre; 
		this.tlf=tlf;
	}
	
	
	public String getAp_Nombre() {
		return ap_Nombre;
	}

	
	public void setAp_Nombre(String ap_Nombre) {
		this.ap_Nombre = ap_Nombre;
	}



	public String getTlf() {
		return tlf;
	}



	public void setTlf(String tlf) {
		this.tlf = tlf;
	}



	public String toString() {
		return "Tarjeta [ap_Nombre=" + ap_Nombre + ", tlf=" + tlf + "]";
	}

	
	//EJERCICIO SORTEDSET


	public boolean equals(Tarjeta t) {
		if(this.ap_Nombre.equalsIgnoreCase(t.ap_Nombre)) 
			return true; 
		else 
			return false;
	}


	@Override
	public int compareTo(Tarjeta t) {
		int comp=this.ap_Nombre.compareToIgnoreCase(t.ap_Nombre);
		return comp;
	}


	
	
	
	
	
	
}
