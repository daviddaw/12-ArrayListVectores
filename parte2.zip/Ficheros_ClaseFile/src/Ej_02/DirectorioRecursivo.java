package Ej_02;

import java.io.File;

import Ej_01.ExcepcionArgumentos;
import Ej_01.ExcepcionFicheroNoExiste;

public class DirectorioRecursivo {
public static void main(String[] args) {
	
		try{
			if(args.length==0)
				throw new ExcepcionArgumentos();
			
			for (int i = 0; i < args.length; i++) {
				File f = new File(args[i]);
				propiedades(f);
				//propiedades(args[i]);//propiedades2
			}
			

		}catch (ExcepcionArgumentos e){
			System.out.println(e+" El programa no tiene argumentos: hay que escribir uno o varios nombres de fichero o directorio" );
		}
	}
	


static void propiedades(File f){

	try{
		if(!(f.exists()))
			throw new ExcepcionFicheroNoExiste();

		if(f.isFile()) {
			System.out.println("Nombre: "+ f.getName()
			+ "\nRuta: "+ f.getAbsolutePath()
					);
		}
		else {
			File [] n;
			System.out.println("Nombre: "+ f.getName());
			n=f.listFiles();
			for(int i=0; i<n.length; i++) {
				propiedades(n[i]);
			}
			
		}

	}catch(ExcepcionFicheroNoExiste e){
		System.out.println(e+ " El fichero no existe");
	}

}



static void propiedades2(String nomFich) {//Falta truco 
	
	try{
		File f = new File(nomFich);
		if(!(f.exists()))
			throw new ExcepcionFicheroNoExiste();

		if(f.isFile()) {
			System.out.println("Nombre: "+ f.getName()
			+ "\nRuta: "+ f.getAbsolutePath()
					);
		}
		else {
			String [] n;
			System.out.println("Nombre: "+ f.getName());
			n=f.list();
			for(int i=0; i<n.length; i++) {
				System.out.println(n[i]);
				propiedades2(n[i]);
			}


		}

	}catch(ExcepcionFicheroNoExiste e){
		System.out.println(e+ " El fichero no existe");
	}


}
}
