package Ej_01;

@SuppressWarnings("serial")
public class ExcepcionFicheroNoExiste extends Exception{


	public ExcepcionFicheroNoExiste(){
		super();
	}

	public ExcepcionFicheroNoExiste(String desc){
		super(desc);
	}
}



