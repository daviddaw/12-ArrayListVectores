package Ej_01;

@SuppressWarnings("serial")

public class ExcepcionArgumentos extends Exception{

	

	public ExcepcionArgumentos(){
		super();
	}

	public ExcepcionArgumentos(String desc){
		super(desc);
	}
}


