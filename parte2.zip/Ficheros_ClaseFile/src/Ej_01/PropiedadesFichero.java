package Ej_01;

import java.io.File;


public class PropiedadesFichero {

	public static void main(String[] args) {
		
		try{
			if(args.length==0)
				throw new ExcepcionArgumentos();
			
			for (int i = 0; i < args.length; i++) {
				propiedades(args[i]);
			}
			

		}catch (ExcepcionArgumentos e){
			System.out.println(e+" El programa no tiene argumentos: hay que escribir uno o varios nombres de fichero o directorio" );
		}
	}
	


	static void propiedades(String nomFich){

		try{

			File f = new File(nomFich);
			if(!(f.exists()))
				throw new ExcepcionFicheroNoExiste();

			if(f.isFile()) {
				System.out.println("Nombre: "+ f.getName()
				+ "\nRuta: "+ f.getAbsolutePath()
				+"\nRuta relativa: "+ f.getPath()
				+"\nSe puede leer: "+ f.canRead()
				+"\nSe puede modificar: "+ f.canWrite()
				+"\nLongitud: "+ f.length()
				+"\nFecha ultima modificacion: " +f.lastModified());
			}
			else {
				System.out.println("Nombre: "+ f.getName()
				+ "\nRuta: "+ f.getAbsolutePath()
				+"\nRuta relativa: "+ f.getPath()
				+"\nSe puede leer: "+ f.canRead()
				+"\nSe puede modificar: "+ f.canWrite()
				+"\nLongitud: "+ f.length()
				+"\nFecha ultima modificacion: " +f.lastModified()
				+"\nLista de ficheros: "+f.list());
			}

		}catch(ExcepcionFicheroNoExiste e){
			System.out.println(e+ " El fichero no existe");
		}

	}

}
