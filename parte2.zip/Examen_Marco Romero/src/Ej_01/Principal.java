package Ej_01;

public class Principal {

	public static void main(String[] args) {
		Alumno a1=new Alumno("pepe", 17, 12, 1995);
		System.out.println("tu numero de la suerte es "+a1.numeroSuerte());

		String nombre;
		int dia, mes, anio;
		
		a1.numeroSuerte();
		
	
		
		/*for( int i=1; i<=2; i++) {
			System.out.println("Nombre del alumno");
			nombre=LeerTeclado.readString();
			System.out.println("Dia de nacimiento del alumno");
			dia=LeerTeclado.readInteger();
			System.out.println("Mes de nacimiento del alumno");
			mes=LeerTeclado.readInteger();
			System.out.println("A�o de nacimiento del alumno");
			anio=LeerTeclado.readInteger();
			Alumno alumnoi =new Alumno(nombre, dia, mes, anio);
			System.out.println(alumnoi.toString());
			
			}*/
			
		
		
		
		
		
		
	}
	
	

}
