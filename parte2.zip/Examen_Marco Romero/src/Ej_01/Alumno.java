package Ej_01;

public class Alumno {
	
	private static int c;
	private int codigo;
	private String nombre;
	private int d_nacimiento;
	private int m_nacimiento;
	private int a_nacimiento;
	

	public Alumno(){
		c++;
		codigo=c;
	}
	
	public Alumno(String nombre, int d_nacimiento, int m_nacimiento, int a_nacimiento) {
		c++;
		codigo=c;
		this.nombre=nombre;
		this.d_nacimiento=d_nacimiento;
		this.m_nacimiento=m_nacimiento;
		this.a_nacimiento=a_nacimiento;
	}


	public int getCodigo() {
		return codigo;
	}


	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public int getD_nacimiento() {
		return d_nacimiento;
	}


	public void setD_nacimiento(int d_nacimiento) {
		this.d_nacimiento = d_nacimiento;
	}


	public int getM_nacimiento() {
		return m_nacimiento;
	}


	public void setM_nacimiento(int m_nacimiento) {
		this.m_nacimiento = m_nacimiento;
	}


	public int getA_nacimiento() {
		return a_nacimiento;
	}


	public void setA_nacimiento(int a_nacimiento) {
		this.a_nacimiento = a_nacimiento;
	}
	
	public  int numeroSuerte() {
		int total, suerte=0, dia, mes, anio;
		dia=getD_nacimiento();
		mes=getM_nacimiento();
		anio=getA_nacimiento();
		total=dia+mes+anio;
		//return total;
		while(total>9) { 
		total=total/10;
		suerte+=total;
		}
		return suerte;
		
	}
	
	public boolean equals(Alumno otroalumno) {
		return this.numeroSuerte()==otroalumno.numeroSuerte();
	}

	@Override
	public String toString() {
		return "Alumno [codigo=" + codigo + ", nombre=" + nombre + ", d_nacimiento=" + d_nacimiento + ", m_nacimiento="
				+ m_nacimiento + ", a_nacimiento=" + a_nacimiento + "]";
	}
	
	
	
}
