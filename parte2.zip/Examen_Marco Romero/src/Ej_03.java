import Ej_01.LeerTeclado;

public class Ej_03 {
	
	
	public static void main(String[] args) {
		
		
		int numeros [] =new int [10]; 
		boolean respuesta=false;
		String teclado;
		
		for(int i=0; i<numeros.length; i++) {
			numeros[i]=(int)(Math.random()*10+1);
			//System.out.print(numeros[i]+" ");	 
		}
		for(int i=0; i<numeros.length; i++) {
			System.out.println("es este tu numero"+numeros[i=1]);	
		
		
		/*teclado=LeerTeclado.readString();

		for(int i=0; i<numeros.length; i++) 
				System.out.println("es este tu numero"+numeros[i]);	

		while (teclado.equalsIgnoreCase("false")) {
			
			teclado=LeerTeclado.readString();

		}*/

	}
}