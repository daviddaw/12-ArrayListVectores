

import java.util.Scanner;

public class Ej_02 {

	public static void main(String[] args) {
		
		try {
			sumaPositivos();
		} catch (Exception e) {
			System.out.println("Se ha introducido un numero negativo");
		}
	}


	static void sumaPositivos() throws Exception {
		Scanner entrada = new Scanner(System.in);
		int n, t=0;
		n=entrada.nextInt();

		while(n!=0) {
			if(n<0)
				throw new ArithmeticException();
			else {
				t+=n;
				n=entrada.nextInt();
			}
		}
		System.out.println(t);
	}
}
