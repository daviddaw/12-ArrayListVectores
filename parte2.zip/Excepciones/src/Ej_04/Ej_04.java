package Ej_04;
import java.util.Scanner;


public class Ej_04 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);

		String nif;
		char l;
		String letras="TRWAGMYFPDXBNJZSQVHLCKE";
		String noUsadas="I, �, O, U";
		int num;
		boolean noNum=false;

		try{
			System.out.println("Introduce tu NIF");//LONGITUD 
			nif=entrada.next();

			for(int i=0; i<nif.length(); i++)
				if(nif.charAt(i)< '0' || nif.charAt(i)>'9')
					noNum=true;
			if(noNum==true)
				throw  new NumberFormatException();


			if(nif.length()<9 || nif.length()>9 ){
				//Exception e = new Exception("LongitudIncorrectaException");-->se puede tambien asi
				throw new LongitudIncorrectaException();
			}

			for(int i=0; i<noUsadas.length(); i++) {//LETRA NO COINCIDE
				if(nif.charAt(8)==noUsadas.charAt(i))
					throw new DniIncorrectoException();
			}

			num=Integer.parseInt(nif.substring(0, 8));
			l=letras.charAt(num%23); 
			System.out.println("La letra del dni coincide: "+l);




		}

		catch(LongitudIncorrectaException e ){
			System.out.println(e+ " El NIF debe tener 9 caracteres");
		}
		catch(DniIncorrectoException e){
			System.out.println(e+ " El �ltimo car�cter no est� en la categor�a de letras v�lidas para el NIF");
		}


	}

}
