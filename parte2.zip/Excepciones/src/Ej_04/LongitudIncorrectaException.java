package Ej_04;

@SuppressWarnings("serial")
public class LongitudIncorrectaException extends Exception {

	

	 public LongitudIncorrectaException() {
	super();
	}
		
	
	public LongitudIncorrectaException(String desc){
		super(desc);
	}
}
