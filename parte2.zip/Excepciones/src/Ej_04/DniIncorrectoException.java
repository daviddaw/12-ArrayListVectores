package Ej_04;

@SuppressWarnings("serial")
public class DniIncorrectoException extends Exception{

	public DniIncorrectoException(){
		super();
	}

	public DniIncorrectoException(String desc){
		super(desc);
	}
}
