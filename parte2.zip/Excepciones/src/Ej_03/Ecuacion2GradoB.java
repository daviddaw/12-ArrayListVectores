package Ej_03;

public class Ecuacion2GradoB {


	public class Ecuacion2Grado {


		private int a,b,c;

		public Ecuacion2Grado(int a, int b, int c) {
			this.a=a;
			this.b=b; 
			this.c=c;
		}

		public int getA() {
			return a;
		}

		public void setA(int a) {
			this.a = a;
		}

		public int getB() {
			return b;
		}

		public void setB(int b) {
			this.b = b;
		}

		public int getC() {
			return c;
		}

		public void setC(int c) {
			this.c = c;
		}


		public void  solucion() throws Exception{
			int x;

			if(a==0 && b==0) {
				Exception e= new Exception("Ecuacion Degenerada ");
				throw e;
			}
			else
				if((Math.pow(b, 2)-4*a*c)< 0) {
					Exception e = new Exception("Raices complejas");
					throw e;

				}
				else
					if(a==0) {
						int res;
						x=c/b;
						res=(int)Math.sqrt(x);
						System.out.println(res);
						Exception e = new Exception("La ecuacion tiene una unica raiz");
						throw e;

					}
					else {
						//ax2+bx+c=0
						x=-((int)Math.pow(b, 2))-((int)Math.sqrt(4*a*c))/2;
						System.out.println(x);

					}


		}


	}
	
}



