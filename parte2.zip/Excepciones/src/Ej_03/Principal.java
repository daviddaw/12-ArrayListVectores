package Ej_03;

public class Principal {

	public static void main(String[] args) {
		Ecuacion2Grado ec = new Ecuacion2Grado(0, 4, 12);
		//ec.solucion();

		
		//SOLUCION B
		try {
			ec.solucion();
		}catch( Exception e) {
			System.out.println(e);
		}

		
	}

}
