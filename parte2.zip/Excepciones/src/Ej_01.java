
public class Ej_01 {

	public static void main(String[] args) {

		int array[]= new int[5];
		for(int i=1; i<array.length; i++)
			array[i]=(int)(Math.random()*1+10);
		
		array[0]=0;
		int num=2;
		int r=0;
		
		try {
			for(int i=0; i<array.length; i++) {
				r=num/array[i];
				System.out.println(r);
				}
			
			//System.out.println(array[6]);
		}
/*		catch (IndexOutOfBoundsException e) {

			System.out.println("fuera del array");
		}
		catch (ArithmeticException e) {
			System.out.println("Division por 0");

		}*/
		catch(Exception e) {
			System.out.println("Fatal Error");
		}


	}

}
