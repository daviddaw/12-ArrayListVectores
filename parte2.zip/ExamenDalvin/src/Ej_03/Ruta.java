package Ej_03;

import java.util.Arrays;

public class Ruta {

	private String recorrido;
	private int numeroTramos;
	private int tramos[];
	
	public Ruta() {
		
	}

	public String getRecorrido() {
		return recorrido;
	}

	public void setRecorrido(String recorrido) {
		this.recorrido = recorrido;
	}

	public int getNumeroTramos() {
		return numeroTramos;
	}

	public void setNumeroTramos(int numeroTramos) {
		this.numeroTramos = numeroTramos;
	}

	public int[] getTramos() {
		return tramos;
	}

	public void setTramos(int[] tramos) {
		this.tramos = tramos;
	}
	
	public static void longitud() {
		
	}
	public static void mRecorridos() {
		
	}

	@Override
	public String toString() {
		return "Ruta [recorrido=" + recorrido + ", numeroTramos=" + numeroTramos + ", tramos=" + Arrays.toString(tramos)
				+ "]";
	}
	
	
}
