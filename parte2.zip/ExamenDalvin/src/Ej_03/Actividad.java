package Ej_03;

public class Actividad {

	private int codigo;
	private String nombre = "Actividad";
	private double precio;
	private int maxPersonas;
	private int numPersonasApuntadas;
	

	
	public Actividad(int codigo, String nombre, double precio, int maxPersonas, int numPersonasApuntadas) {
		
		super();
		int i=1;
		this.precio =precio;
		this.nombre = "Actividad: "+" "+nombre;
		this.codigo = codigo;
		this.precio = precio;
		this.numPersonasApuntadas=numPersonasApuntadas;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getMaxPersonas() {
		return maxPersonas;
	}

	public void setMaxPersonas(int maxPersonas) {
		this.maxPersonas = maxPersonas;
	}

	public int getNumPersonasApuntadas() {
		return numPersonasApuntadas;
	}

	public void setNumPersonasApuntadas(int numPersonasApuntadas) {
		this.numPersonasApuntadas = numPersonasApuntadas;
	}

	@Override
	public String toString() {
		return "Actividad [codigo=" + codigo + ", nombre=" + nombre + ", precio=" + precio + ", maxPersonas="
				+ maxPersonas + ", numPersonasApuntadas=" + numPersonasApuntadas + "]";
	}
	
	
}
