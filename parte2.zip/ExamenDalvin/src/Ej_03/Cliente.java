package Ej_03;

public class Cliente {
	
	private String nombre;
	private  Actividad Actividades[];
	
	public Cliente() {
		
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Actividad[] getActividades() {
		return Actividades;
	}

	public void setActividades(Actividad[] actividades) {
		Actividades = actividades;
	}
	public void contratarActividad(Actividad actividad) {
		
	}
	
	public void contarRutas() {
		
	}
	public void calcularImporte() {
		
	}
	
}
