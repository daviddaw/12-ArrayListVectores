package Ej_03;

public class Principal {

	public static void main(String[] args) {
	
		
		
		Actividad act1 = new Actividad(50,"Juan",500,20,12);
		Actividad act2 = new Actividad(50,"Fernando",500,20,12);
		
		
	
	}
	public static void nuevaActividadCliente() {
		
	}

}
