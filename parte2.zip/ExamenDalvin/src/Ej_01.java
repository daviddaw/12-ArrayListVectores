import java.util.Scanner;

public class Ej_01 {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		System.out.println("GENERADOR DE CLAVES - INTRODUZCA NOMBRES Y APELLIDOS");
		String nombre,apellido;
		System.out.println("1 - Introduce el nombre");
		nombre = entrada.nextLine();
		System.out.println("2 -Introduce el apellido");
		apellido = entrada.nextLine();

		concat(nombre, apellido);


	}

	public static void concat(String nombre,String apellido) {

		String concat = apellido+nombre;
		String aux2 = null;
		if(concat.length()<12) {
			int aux=concat.length();
			aux2 =concat+ concat.substring(concat.length(), aux);
			System.out.println((aux2+concat).substring(0, 12).toLowerCase().replace('a','@').replace('e','@').replace('i','@').replace('o','@').replace('u','@').replaceAll(" ", ""));
		}else  {
			System.out.println(concat.toLowerCase().replace('a','@').replace('e','@').replace('i','@').replace('o','@').replace('u','@').replaceAll(" ", ""));
		} 
		
		


	}


}
