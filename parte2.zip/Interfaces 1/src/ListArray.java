
public class ListArray implements IArray {
	
	int array[];
	int nelem;

	public ListArray(int tam) {
		this.array=new int[tam];
		nelem=0;
				
	}
	
	public void addFirst(int elem) {

		if(getSize(array)==array.length)
			System.out.println("El array esta lleno");
		else
			for(int i=array.length; i<=0; i--)
				array[i+1]=array[i];
		
		array[0]=elem;
		nelem++;
	}

	

	public void addLast(int elem) {
		
		if(getSize(array)<array.length)
			array[elem]=elem;
		else 
		System.out.println("El array esta lleno");
	}


	
	
	public void removeFirst() {
		array[0]=0;
		
	}

	
	public void removeLast() {
		array[array.length]=0;
	}

	@Override
	public void insertAt(int index, int elem) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void contains(int elem) {
		// TODO Auto-generated method stub
		
	}

	public int getSize(int array[]) {
		int size=0;
		for(int i=0; i<array.length; i++)
			if(array[i]!=0)
				size++;
		return size;
		
	}

	@Override
	public void getIndex(int elem) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getFirst() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getLast() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void removeAt(int index) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeAll(int elem) {
		// TODO Auto-generated method stub
		
	}
	
	
	
 
}
