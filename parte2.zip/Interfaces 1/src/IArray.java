

public interface IArray {
	
	
	
	public void addFirst(int elem);
	
	public void addLast(int elem);
	
	public void removeFirst();
	
	public void removeLast();
	
	public void insertAt(int index, int elem);
	
	public  boolean isEmpty();
	
	public void contains(int elem);
	
	public int getSize(int array[]);
	
	public void getIndex(int elem);
	
	public int getFirst();
	
	public int getLast();
	
	public void removeAt(int index);
	
	public void removeAll(int elem);
	
	
}
