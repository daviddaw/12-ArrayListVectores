package Ej_02;

public class Chalet extends Vivienda{

	private int mJardin;
	private boolean piscina;
	
	public Chalet() {
		
		
	}
	
	public Chalet(int nHabitaciones, int mCuadaros, String calle, int numero, int mJardin, boolean piscina) {
		super(nHabitaciones, mCuadaros, calle, numero);
		this.mJardin=mJardin;
		this.piscina=piscina;
	}

	public int getmJardin() {
		return mJardin;
	}

	public void setmJardin(int mJardin) {
		this.mJardin = mJardin;
	}

	public boolean isPiscina() {
		return piscina;
	}

	public void setPiscina(boolean piscina) {
		this.piscina = piscina;
	}
	
	
	

	@Override
	public String toString() {
		return super.toString()+"Chalet [mJardin=" + mJardin + ", piscina=" + piscina + "]";
	}
	
	
	
	
}
