package Ej_02;

public class Vivienda {
	
	private int nHabitaciones, mCuadrados, numero;
	private String calle;
	
	public Vivienda(){
		
	}

	public Vivienda(int nHabitaciones, int mCuadaros, String calle, int numero) {
		this.nHabitaciones=nHabitaciones;
		this.mCuadrados=mCuadaros;
		this.calle=calle;
		this.numero=numero;
		
	}

	public int getnHabitaciones() {
		return nHabitaciones;
	}

	public void setnHabitaciones(int nHabitaciones) {
		this.nHabitaciones = nHabitaciones;
	}

	public int getmCuadrados() {
		return mCuadrados;
	}

	public void setmCuadrados(int mCuadrados) {
		this.mCuadrados = mCuadrados;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getCalle() {
		return calle;
	}

	public void setCalle(String calle) {
		this.calle = calle;
	}

	@Override
	public String toString() {
		return "Vivienda [nHabitaciones=" + nHabitaciones + ", mCuadrados=" + mCuadrados + ", numero=" + numero
				+ ", calle=" + calle + "]";
	}
	
	
	
	
}
