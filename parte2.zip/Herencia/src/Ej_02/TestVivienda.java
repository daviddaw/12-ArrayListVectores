package Ej_02;

public class TestVivienda {

	public static void main(String[] args) {
		
		 Vivienda vivienda=new Vivienda(2, 50, "leonardo", 12);
		 Chalet chalet1 = new Chalet(6, 250, "lujos", 20, 40, false);
		 Chalet chalet2= new Chalet(8, 600, "mas", 5, 30, true);
		 Palacio palacio = new Palacio(1000, "santo", 4, true);
		 

		 Vivienda arrayviviendas[]= {vivienda, chalet1, chalet2, palacio};
		 int  chalets=0;
		 
		 for (int i = 0; i < arrayviviendas.length; i++) {
			 if(arrayviviendas[i] instanceof Chalet)
				 chalets++;
			 System.out.println(arrayviviendas[i].toString());
		 }
		 System.out.println("Hay "+chalets+ " chalets");

	}

}
