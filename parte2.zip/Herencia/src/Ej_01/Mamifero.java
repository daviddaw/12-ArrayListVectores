package Ej_01;

public class Mamifero extends Animal{

	private int nCrias;
	private int mesesEmbarazo;
	
	
	public Mamifero() {
	
	}
	
	public Mamifero(String nComun,String nEspecifico,double peso,double tama�o,int nCrias, int mesesEmbarazo) {

		super(nComun, nEspecifico, peso, tama�o);
		this.nCrias = nCrias;
		this.mesesEmbarazo = mesesEmbarazo;
	}
	public int getnCrias() {
		return nCrias;
	}
	public void setnCrias(int nCrias) {
		this.nCrias = nCrias;
	}
	public int getMesesEmbarazo() {
		return mesesEmbarazo;
	}
	public void setMesesEmbarazo(int mesesEmbarazo) {
		this.mesesEmbarazo = mesesEmbarazo;
	}

	@Override
	public String toString() {
		return super.toString()+ "Mamifero [nCrias=" + nCrias + ", mesesEmbarazo=" + mesesEmbarazo + "]";
	}
	
	
}
