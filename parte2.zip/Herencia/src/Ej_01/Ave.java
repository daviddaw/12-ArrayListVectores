package Ej_01;

public class Ave extends Animal{

	private int nHuevos;
	private boolean volar;
	
	public Ave ( ) {
		
	}
	
	public Ave(String nComun, String nEspecifico, double peso, double tama�o, int nHuevos, boolean volar) {
		super(nComun, nEspecifico, peso, tama�o);
		this.nHuevos = nHuevos;
		this.volar = volar;
	}
	
	public int getnHuevos() {
		return nHuevos;
	}

	public void setnHuevos(int nHuevos) {
		this.nHuevos = nHuevos;
	}

	public boolean isVolar() {
		return volar;
	}

	public void setVolar(boolean volar) {
		this.volar = volar;
	}

	@Override
	public String toString() {
		return super.toString()+ "Ave [nHuevos=" + nHuevos + ", volar=" + volar + "]";
	}
	
}
 
