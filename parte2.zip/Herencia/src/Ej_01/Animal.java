package Ej_01;

public class Animal {


	private String nComun;
	private String nEspecifico;
	private double peso;
	private double tama�o;
	
	public Animal() {
		
	}
	
	public Animal(String nComun, String nEspecifico, double peso, double tama�o) {
		this.nComun = nComun;
		this.nEspecifico = nEspecifico;
		this.peso = peso;
		this.tama�o = tama�o;
	}


	public String getnComun() {
		return nComun;
	}


	public void setnComun(String nComun) {
		this.nComun = nComun;
	}


	public String getnEspecifico() {
		return nEspecifico;
	}


	public void setnEspecifico(String nEspecifico) {
		this.nEspecifico = nEspecifico;
	}


	public double getPeso() {
		return peso;
	}


	public void setPeso(double peso) {
		this.peso = peso;
	}


	public double getTama�o() {
		return tama�o;
	}


	public void setTama�o(double tama�o) {
		this.tama�o = tama�o;
	}

	@Override
	public String toString() {
		return "Animal [nComun=" + nComun + ", nEspecifico=" + nEspecifico + ", peso=" + peso + ", tama�o=" + tama�o
				+ "]";
	}
	
	
	
}
