package Ej_01;

public class MamiferosTerrestre extends Mamifero{

	private int nPatas;

	public MamiferosTerrestre() {
		
	}
	
	public MamiferosTerrestre(String nComun,String nEspecifico,double peso,double tama�o,int nCrias, int mesesEmbarazo, int nPatas) {
		super(nComun, nEspecifico, peso, tama�o, nCrias, mesesEmbarazo);
		this.nPatas = nPatas;
	}

	public int getnPatas() {
		return nPatas;
	}

	public void setnPatas(int nPatas) {
		this.nPatas = nPatas;
	}

	@Override
	public String toString() {
		return super.toString()+ "MamiferosTerrestre [nPatas=" + nPatas + "]";
	}

	
}
