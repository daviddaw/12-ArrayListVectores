package Ej_01;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		
		Animal rana = new Animal("Rana", "Ranus", 1, 1);
		Mamifero ballena = new Mamifero("Ballena", "Ballenus", 180, 3, 2, 16);
		MamiferosTerrestre perro = new MamiferosTerrestre("Perro", "Canis dogo", 2, 2, 5, 12, 4);
		Ave avestruz = new Ave("Avestruz", "Avestruzen", 180, 2, 4, false);
		Ave paloma = new Ave("paloma", "Palomun", 1, 1, 10, true);
		
		System.out.println(rana.toString());
		System.out.println(ballena.toString());
		System.out.println(perro.toString());
		System.out.println(avestruz.toString());
		System.out.println(paloma.toString());
		
		rana.setPeso(2);
		ballena.setPeso(200);
		paloma.setnHuevos(35);
		perro.setPeso((perro.getPeso()*0.10)+perro.getPeso());
		ballena.setMesesEmbarazo(14);
		System.out.println("\n Con los cambios hechos");
		System.out.println("");
		System.out.println(rana.toString());
		System.out.println(ballena.toString());
		System.out.println(perro.toString());
		System.out.println(paloma.toString());
		
		
	}

}
