package Ej_03;

public class Camion extends Vehiculos{
	
	/*private String marca;
	private String matricula;
*/	private int nRuedas;
	//private int autonomia;
	private int carga;
	private int limCarga;
	
	private String conductor;
	
	
	public Camion() {
		
	}
	
	public Camion(String marca, String matricula, int autonomia, int nRuedas, int carga, int limCarga, String conductor) {
		super(marca, matricula, autonomia);
		this.nRuedas=nRuedas;
		
		if(carga>limCarga)
			this.carga=limCarga;
		else
			this.carga=carga;
		
		this.limCarga=limCarga;
		this.conductor=conductor;
		
	}
	
	
	
	public int getnRuedas() {
		return nRuedas;
	}
	
	public void setnRuedas(int nRuedas) {
		this.nRuedas = nRuedas;
	}
	
	
	public int getLimCarga() {
		return limCarga;
	}
	
	public void setLimCarga(int limCarga) {
		this.limCarga = limCarga;
	}
	
	public int getCarga() {
		return carga;
	}
	
	public void setCarga(int carga) {
		this.carga = carga;
	}
	
	public String getConductor() {
		return conductor;
	}
	
	public void setConductor(String conductor) {
		this.conductor = conductor;
	}

	
	public void cambiarCounductor(String conductor) {
		setConductor(conductor);
	}
	
	
	public void cargar(int carga){
		if(carga>this.limCarga)
			setCarga(limCarga);
		else 
			setCarga(carga+this.carga);
		
	}
	

	
	public void descargar(int descarga) {
		if(descarga>this.carga)
			setCarga(0);
		else 
			setCarga(this.carga-descarga);
	}
	
	
	
	
	
	public String listar() {
		return super.toString()+ " Camion [nRuedas=" + nRuedas + ", carga=" + carga + ", limCarga=" + limCarga +  ", conductor=" + conductor
				+ "]";
	}

	
	
	
	
	
	
	

}
