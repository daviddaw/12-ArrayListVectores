package Ej_03;

public class Coche extends Vehiculos {
	
	//private String marca, matricula;
	private final int nRuedas=4;
	//private int autonomia;
	private String color;
	private int nPasajeros;
	private boolean descapotable;
	
	
	
	public Coche() {
		
	}
	
	public Coche(String marca, String matricula, int autonomia, String color, int nPasajeros, boolean descapotable) {
		super(marca, matricula, autonomia);
		this.color=color;
		this.nPasajeros=nPasajeros;
		this.descapotable=descapotable;
		
	}
	
	
	/*public String getMarca() {
		return marca;
	}
	
	public void setMarca(String marca) {
		this.marca = marca;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	public int getAutonomia() {
		return autonomia;
	}
	
	public void setAutonomia(int autonomia) {
		this.autonomia = autonomia;
	}*/
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public int getnPasajeros() {
		return nPasajeros;
	}
	
	public void setnPasajeros(int nPasajeros) {
		this.nPasajeros = nPasajeros;
	}
	
	public boolean isDescapotable() {
		return descapotable;
	}
	
	public void setDescapotable(boolean descapotable) {
		this.descapotable = descapotable;
	}
	
	public int getnRuedas() {
		return nRuedas;
	}

	
	
	public void pintarCoche(String color) {
		setColor(color);
		
	}

	
	public String listar() {
		return super.listar()+ " Coche [nRuedas=" + nRuedas + ", color=" + color + ", nPasajeros=" + nPasajeros + ", descapotable="
				+ descapotable + "]";
	}
	
//	

}
