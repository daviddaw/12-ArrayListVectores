package Ej_03;

public class Vehiculos {

	private String marca;
	private String matricula;
	private int autonomia;
	
	public Vehiculos() {
		
	}
	
	public Vehiculos(String marca, String matricula, int autonomia) {
		this.marca=marca; 
		this.matricula=matricula;
		this.autonomia=autonomia;
		
	}

	public String getMarca() {
		return marca;
	}
	

	public void setMarca(String marca) {
		this.marca = marca;
	}
	

	public String getMatricula() {
		return matricula;
	}
	

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	

	public int getAutonomia() {
		return autonomia;
	}
	

	public void setAutonomia(int autonomia) {
		this.autonomia = autonomia;
	}

	
	public String listar() {
		return "Vehiculos [marca=" + marca + ", matricula=" + matricula + ", autonomia=" + autonomia + "]";
	}
	
	
	
}
