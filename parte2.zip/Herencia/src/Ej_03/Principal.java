package Ej_03;

public class Principal {

	public static void main(String[] args) {
		//Vehiculos vehiculo;
		
	
		Coche coche= new Coche("ford", "SAD", 200, "verde", 4, false);
		Camion camion= new Camion("merc", "asdl", 400, 16, 150, 500, "pepe");
		
		System.out.println(coche.listar());
		coche.pintarCoche("azul");
		System.out.println(coche.listar());
		
		System.out.println(camion.listar());
		
	
		/*camion.cargar(150);
		System.out.println(camion.listar());
		*/
		
		
		/*
		camion.descargar(50);
		System.out.println(camion.listar());
		*/
		

	}

}
