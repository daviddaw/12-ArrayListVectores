import java.util.Scanner;

public class Ej_01 {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		String arraynombres[]= new String[15];
		int arrayNotas[]= new int [15];
		int arrayAnios[]= new int [15]; 
		int aInferior, aSuperior, anio;
		int joven=0, posjo=0, c=0;
		int porcentaje;
		
		for(int i=0; i<arraynombres.length; i++)
			arraynombres[i]="Alumno"+(i+1);
		
		
		for(int i=0; i<arraynombres.length; i++)
			System.out.println(arraynombres[i]);
		
		for(int i=0; i<arrayNotas.length; i++)
			arrayNotas[i]=(int)(Math.random()*10+1);
		
		
		for(int i=0; i<arrayNotas.length; i++)
			System.out.print(arrayNotas[i]+" ");

		System.out.println("\nIntroduce el a�o inferior ");
		aInferior=entrada.nextInt();
		System.out.println("Introduce el a�o superior");
		aSuperior=entrada.nextInt();
		

		for(int i=0; i<arrayAnios.length; i++) {
			do {
			System.out.println("Introduce el a�o del Alumno");
			anio=entrada.nextInt();
			}while(anio<aInferior || anio>aSuperior);
				arrayAnios[i]=anio;
		}
		
		/*
			for(int i=0; i<arrayAnios.length; i++)
				System.out.println(arrayAnios[i]);*/
	
		
		for(int i=0; i<arrayAnios.length; i++) {
			if(arrayAnios[i]>joven) {
				joven=arrayAnios[i];
				posjo=i;	
			}	
		}
	
		System.out.println("El alumno mas joven es el "+arraynombres[posjo]+" y su nota es "+ arrayNotas[posjo]);
		
		//porcentaje--arreglar
		//rango 1990 a 2001
		for(int i=0; i<arrayNotas.length; i++)
			if(arrayNotas[i]>5 && (arrayAnios[i]<=2000 || arrayAnios[i]<=1996))
				c++;
		
		System.out.println(c);
		porcentaje=(15/c)*100;
		System.out.println("porcentaje de aprobados "+ porcentaje);
		
	}

}
