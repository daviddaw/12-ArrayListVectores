import java.util.Scanner;

public class Alumno {
	
	Scanner entrada = new Scanner(System.in);
	
	
	private String nombre; 
	private int nota; 
	private int aNacimiento; 
	private final int  aInferior=1990; 
	private final int  aSuperior=2000; 
	private static int c;
	private int codigo;
	
	public Alumno(){
		c++;
		codigo=c;
	}
	
	public Alumno(int aNacimiento) {
		c++;
		codigo=c;
		this.nombre="Alumno"+codigo;
		this.nota=(int)(Math.random()*10+1);
		if(aNacimiento<aInferior || aNacimiento>aSuperior)
			this.aNacimiento=aNacimiento;
			
		
	}

	
	public String getNombre() {
		return nombre;
	}


	public int getNota() {
		return nota;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}

	public int getaNacimiento() {
		return aNacimiento;
	}

	public void setaNacimiento(int aNacimiento) {
		this.aNacimiento = aNacimiento;
	}


	public int getaInferior() {
		return aInferior;
	}

	public int getaSuperior() {
		return aSuperior;
	}
	

	@Override
	public String toString() {
		return "Alumno [nombre=" + nombre + ", nota=" + nota + ", aNacimiento=" + aNacimiento + "]";
	}
	
	
	
	
}
