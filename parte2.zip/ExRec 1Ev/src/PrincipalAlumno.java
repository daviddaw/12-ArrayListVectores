import java.util.Scanner;

public class PrincipalAlumno {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		
		int anio;
	
		
		//System.out.println(al1.toString());
		
		for( int i=1; i<=15; i++) {
			System.out.println("A�o de nacimiento del alumno");
			anio=entrada.nextInt();
			Alumno al1= new Alumno(anio);
			System.out.println(al1.toString());
			
			}
		

	}

}
