package paqueteCodigo;

public class Ruta extends Actividad { //herencia
	
	 String recorrido;
	 int numeroTramos;
	 int[]tramos;
	
	
	public Ruta(int codigo, String nombre, double precio, int maxPersonas, int numPersonasApuntadas, String recorrido,
			 int[] tramos) {
		super(codigo, nombre, precio, maxPersonas, numPersonasApuntadas);
		this.recorrido = recorrido;
		this.numeroTramos = tramos.length;
		this.tramos = tramos;
	}

	
	
	public int calcularLongitud () {
		
		int suma=0;
		for (int i=0; i<tramos.length; i++) {			
			suma+=tramos[i];
		}		
		return suma;
	}
	
	public int calcularTramo(int metros) {
		int iTramo=0;	
		if (metros>calcularLongitud()) //si los metros exceden de la longitud total de la ruta
			iTramo=-1;
		else { //si no, recorro el array de tramos sumando cada tramo hasta que exceda de los metros introducidos
			int suma=0,  i=0; 
			boolean encontrado=false;
			while (i<tramos.length && encontrado==false) {
				suma+=tramos[i];
				if (suma>=metros) {
					iTramo=i;
					encontrado=true;
				}
				i++;
			}
		}
		return iTramo;
	}
	
	public String toString () {
		
		String salida;
		salida=super.toString()+"Ruta de Recorrido: "+this.recorrido+"\n";
		salida+="Numero de tramos: "+this.numeroTramos+"\n";
		for (int i = 0; i < tramos.length; i++) {
			salida+=tramos[i]+"|";
		}
		salida+="\n";
		return salida;
	}



	public int getNumeroTramos() {
		return numeroTramos;
	}



	public void setNumeroTramos(int numeroTramos) {
		this.numeroTramos = numeroTramos;
	}
	
	
	
	
}
