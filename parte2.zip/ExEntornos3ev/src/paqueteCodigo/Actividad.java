package paqueteCodigo;

public class Actividad {
	
	 int codigo;
	 String nombre;
	 double precio;
	 int maxPersonas;
	 int numPersonasApuntadas;

	
	
	
	public Actividad(int codigo, String nombre, double precio, int maxPersonas, int numPersonasApuntadas) {
		this.codigo = codigo;
		this.nombre = nombre;
		if (precio<=500)
			this.precio = precio;
		else
			precio=500;
		this.maxPersonas = maxPersonas;
		if(numPersonasApuntadas<maxPersonas)
			this.numPersonasApuntadas = numPersonasApuntadas;
		else
			this.numPersonasApuntadas=0;
	}



	public String toString () {
		
		String salida;
		salida="Codigo: "+this.codigo+"\n";
		salida+="Nombre: "+this.nombre+"\n";
		salida+="Precio: "+this.precio+"\n";
		salida+="Maximo de personas: "+this.maxPersonas+"\n";
		salida+="Personas apuntadas: "+this.numPersonasApuntadas+"\n";
		return salida;
	}
}
