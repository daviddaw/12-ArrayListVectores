package paqueteCodigo;

public class Cliente {
	
	private String nombre;
	private Actividad actividadesCliente[];
	private static int cont=1;
	private static final int tamanio=4;
	//es c�modo usar una variable contador de Actividades Contratadas que indica las actividades que realmente tiene el cliente
	private int activContratadas;
	
	public Cliente () {
		
		this.nombre="Cliente"+Cliente.cont++;
		this.actividadesCliente=new Actividad[tamanio];
		this.activContratadas=0;
	}
	
	public String getNombre () {
		
		return this.nombre;
	}
	
	public int getActivContratadas() {
		return activContratadas;
	}

	
	
	
	public boolean contratarActividad (Actividad actividad) {
		//validar si la actividad no supera el n�mero de personas 
		//y si el cliente no tiene el m�ximo de actividades contratadas		
		if (actividad.numPersonasApuntadas==actividad.maxPersonas) {
			System.out.println("La actividad est� completa");
			return false;
		}		
		else 
			if (activContratadas==4) {// o a actividadesCliente.length() (4 en nuestro caso)
				System.out.println("Lo sentimos el cliente tiene el m�ximo de actividades contratadas");
				return false;
			}				
			else {	actividadesCliente[activContratadas]=actividad;
					//se guarda en el array en la posici�n que indica activContratadas que empieza valiendo 0
					activContratadas++;
					//se actualiza las personas apuntadas a la actividad
					actividad.numPersonasApuntadas++;
					return true;
				}				
	}
	
	
	
	public int contarRutas () { //contar cu�ntas rutas tiene de longitud >1000
		
		int cont=0, i=0;
		Ruta ruta;
		while(i<activContratadas) {
			if (actividadesCliente[i] instanceof Ruta) {
				ruta=(Ruta)actividadesCliente[i];
				if (ruta.calcularLongitud()>1000)
					cont++;
			}
			i++;			
		}
		return cont;
		//System.out.println("Las rutas contratadas por el cliente de longitud mayor de 1000 son "+cont);
	}	
		
	
	public int calcularImporte () {
		
		int importe=0;
		
		for (int i=0; i<actividadesCliente.length; i++) {
			//para calcular el importe total no hay que hacer casting porque todas las actividades tienen precio
			if(actividadesCliente[i]!=null)
			importe+=actividadesCliente[i].precio;
		}
		
		//ser�a mejor
		/*for (int i=0; i<activContratadas; i++) {
			//para calcular el importe total no hay que hacer casting porque todas las actividades tienen precio
			
			importe+=actividadesCliente[i].getPrecio();
		}*/
		
		return importe;
		//System.out.println("El importe de todas las actividades contratadas por el cliente es "+importe);
	}
	
	public String toString () {
		
		String salida;
		salida="Nombre: "+this.nombre+"\n";
		for (int i = 0; i < actividadesCliente.length; i++) {
			if (actividadesCliente[i]!=null)
				salida+=actividadesCliente[i].nombre+"|";
			
		}
		salida+="\n";
	
		return salida;
	}
	
}
