import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import paqueteCodigo.Actividad;

public class testActividad {

	
	private Actividad a;
	
	
	@Before
	public void setUp() throws Exception {
		
		a= new Actividad(1, "as", 100, 5, 2);
	}

	@Test
	public void test() {
		Actividad a2; 
		a2= new Actividad(1, "as", 100, 5, 2);
		assertTrue(a2==a);
	}

}
