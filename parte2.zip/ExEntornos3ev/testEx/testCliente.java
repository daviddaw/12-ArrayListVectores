import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import paqueteCodigo.Actividad;
import paqueteCodigo.Cliente;
import paqueteCodigo.Ruta;

public class testCliente {

	private Actividad a;
	private Actividad a2;
	private Cliente c; 
	private Ruta r;
	private Ruta r2;


	@Before
	public void setUp() throws Exception {
		a= new Actividad(1, "as", 100, 5, 2);
		c= new Cliente();

	}

	@Test
	public void testContratarActividades() {
		c.contratarActividad(a);
		assertTrue(c.contratarActividad(a)==true);
		//assertTrue(c.getActivContratadas()==1);
	}



	@Test
	public void testContratarActividades2() {

		a2= new Actividad(2, "as", 100, 4, 4);
		c.contratarActividad(a2);

		assertTrue(c.contratarActividad(a2)==false);

	}




	@Test
	public void testContarRutas() {

		int tramos[]= {100,200,300};
		int tramos2[]= {800,200,300};

		r = new Ruta(1, "dd", 100, 5, 2, "ab", tramos);
		r2 = new Ruta(2, "bb", 400, 5, 2, "bb", tramos2);

		c.contratarActividad(r);
		c.contratarActividad(r2);

		assertTrue(c.contarRutas()==1);


	}





}	