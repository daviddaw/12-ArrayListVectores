import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import paqueteCodigo.Ruta;

public class testRuta {
	
	private Ruta r;
	private Ruta r2;

	@Before
	public void setUp() throws Exception {
		
		int tramos[]= {100,200,300};
		int tramos2[]= {400,300,600};

		r = new Ruta(1, "dd", 100, 5, 4, "ab", tramos);
		r2 = new Ruta(2, "bb", 400, 5, 2, "bb", tramos2);
	}

	@Test
	public void testCalcularLongitud() {

		assertTrue(r.calcularLongitud()==600);
	}



	@Test
	public void testContarRutasExcede() {
		int metros=800;
		assertTrue(r.calcularTramo(metros)==-1);
		
	
	}
	

/*	@Test
	public void testContarRutasvacio() {
		int [] tramos2= new int[3];
		
		r2 = new Ruta(2, "bb", 400, 5, 2, "bb", tramos2);
		int metros=200;
		
		assertTrue(r2.calcularTramo(metros)==0);
		
	}*/
	

	@Test
	public void testContarRutas() {
		int metros=400; 
		assertTrue(r2.calcularTramo(metros)==0);
		
	}
		
	
	
	
}