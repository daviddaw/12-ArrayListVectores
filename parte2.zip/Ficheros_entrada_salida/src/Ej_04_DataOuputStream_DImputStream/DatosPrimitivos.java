package Ej_04_DataOuputStream_DImputStream;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class DatosPrimitivos {

	public static void main(String[] args) throws IOException {
		Scanner entrada = new Scanner(System.in);
		
		int cod;
		String respuesta,nombre;
		boolean rep;
		double nota;
		DataOutputStream f_grabar;
		DataInputStream f_leer;
		Alumno al;
		

		f_grabar = new DataOutputStream(new FileOutputStream("alumno.dat"));

		
		do {
			System.out.println("Introduce el codigo del alumno");
			cod=entrada.nextInt();

			System.out.println("Introduce el nombre del alumno");
			nombre=entrada.next();

			System.out.println("�Es repetidor?");
			rep=entrada.nextBoolean();

			System.out.println("Introduce la nota del alumno");
			nota=entrada.nextDouble();

			al=new Alumno(cod, nombre, rep, nota);
			al.guardarAlumnoAlFichero(f_grabar);

			System.out.println("Agregar otro alumno");
			respuesta=entrada.next();
		}while(respuesta.equalsIgnoreCase("s"));


		
		


		f_grabar.flush();
		f_grabar.close();


		//Leemos los alumnos a traves de el fichero alumno.dat
		f_leer = new DataInputStream(new FileInputStream("alumno.dat"));
		int cr=0;
		int nT=0;
		
		
		while(f_leer.available()>0){
			al.leerAlumnoDelFichero(f_leer);
			al.mostrarAlumno();
			if(al.isRepetidor()==true) {
				cr++;
				nT+=al.getNota();
				
			}
			
		}

		f_leer.close();
		System.out.println("\nAlumnos Repetidores:"+cr);
		System.out.println("La media de los alumnos repetidores es : "+nT/cr);
	}

}
