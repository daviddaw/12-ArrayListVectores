package Ej_04_DataOuputStream_DImputStream;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class Alumno {
	
	private int codigo;
	private String nombre;
	private boolean repetidor;
	private double nota;
	
	public Alumno(){
		
	}

	
	public  Alumno(int codigo, String nombre, boolean repetidor, double nota){
		this.codigo=codigo;
		this.nombre=nombre; 
		this.repetidor=repetidor;
		this.nota=nota;
	}


	public int getCodigo() {
		return codigo;
	}


	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public boolean isRepetidor() {
		return repetidor;
	}


	public void setRepetidor(boolean repetidor) {
		this.repetidor = repetidor;
	}


	public double getNota() {
		return nota;
	}


	public void setNota(double nota) {
		this.nota = nota;
	}
	
	
	public void guardarAlumnoAlFichero(DataOutputStream fich) throws IOException{
		fich.write(codigo);
		fich.writeUTF(nombre);
		fich.writeBoolean(repetidor);
		fich.writeDouble(nota);
	}
	
	
	public void leerAlumnoDelFichero(DataInputStream fich) throws IOException{
		codigo=fich.read();
		nombre=fich.readUTF();
		repetidor=fich.readBoolean();
		nota=fich.readDouble();
	}
	
	
	public void mostrarAlumno(){
		System.out.println("\n");
		
		System.out.println("Codigo: "+codigo
				+"\nNombre: "+nombre
				+"\nRepetidor: "+repetidor
				+"\nNota: "+nota);		
	}
	
	
}
