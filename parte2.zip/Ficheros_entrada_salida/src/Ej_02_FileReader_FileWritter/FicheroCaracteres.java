package Ej_02_FileReader_FileWritter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;


public class FicheroCaracteres {

	public static void main(String[] args) throws IOException {//el throws es de el bufferedReader
		
		Scanner entrada = new Scanner(System.in);//para el int del switch con bf fallo ?�
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		
		String nombreF;
		File f=null;
		FileWriter fw=null;
		FileReader fr=null;
		String contenidoF;
		
		System.out.println("Introduce el nombre del fichero");
		nombreF=bf.readLine();

		f=new File(nombreF);

		if(!(f.exists())){

			entradaDatos(f);

		}
		else {
			
			int n; 
			
			System.out.println("El fichero ya existe. Opciones disponibles:"
					+"\n1. Reescribir el fichero"
					+ "\n2. A�adir texto al final del fichero");

			n=entrada.nextInt(); 

			switch (n) {
			case 1:
				entradaDatos(f);
				break;

			case 2:

				System.out.println("Introduce los datos para a�adirlos al fichero");
				contenidoF=bf.readLine();

				try {
					fw= new FileWriter(f, true);
					fw.write(contenidoF);


				} catch (IOException e) {
					System.out.println(e);
					e.printStackTrace();
				}
				try{
					fw.close();
				}catch(IOException e){
					System.out.println(e);
				}
				break;

			}
		}
		
		
		System.out.println("Leemos el fichero");

		try {
			fr=new FileReader(f);
			char leido;
			char fin=(char)(-1);
			leido=(char)fr.read();

			while((leido= (char)fr.read()) != fin)
				System.out.print(leido);
			
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}
	
	
	
	
		static void entradaDatos(File f){
			
			BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
			FileWriter fw=null;
			String contenidoF;
			
			
			System.out.println("Introduce los datos del fichero");
			try {
				fw=new FileWriter(f);

				contenidoF=bf.readLine();
				fw.write(contenidoF);

			} catch (IOException e) {
				System.out.println(e);
				e.printStackTrace();
			}
			try{
				fw.close();
			}catch(IOException e){
				System.out.println(e);
			}

	}
	
		
}
