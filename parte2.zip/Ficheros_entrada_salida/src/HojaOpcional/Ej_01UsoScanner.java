package HojaOpcional;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Ej_01UsoScanner {


	public static void main(String[] args) throws FileNotFoundException {

		File f = new File("datos.txt");
		int c=0;
		
		if(f.exists()) {
			Scanner entrada=new Scanner(f);
			entrada.useDelimiter(" ");
			while (entrada.hasNext()) {
				System.out.println(entrada.next());
				c++;
			}
			System.out.println("total de lineas "+c);
			entrada.close();
		} 



	}
}
