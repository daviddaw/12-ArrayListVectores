package Ej_01;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class FicheroBytes {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);

		String nombreF; 
		String cadena;
		File f=null;
		FileOutputStream fos=null;
		char c;




		System.out.println("Introduce un nombre de fichero");
		nombreF=entrada.next();
		f= new File(nombreF);
 
		if(!(f.exists())){
			/*System.out.println("Introduce los datos del fichero");
			cadena=entrada.next();

			try{
				fos=new FileOutputStream(f);
				for(int i=0; i<cadena.length(); i++){
					c=cadena.charAt(i);
					fos.write(c);
				}
			}catch (IOException e){
				System.out.println(e);
			}
			try {
				fos.close();
			} catch (IOException e) {
				System.out.println(e);
			}*/
			entradaDatos(f);

		}
		else {
			int n; 
			
			System.out.println("El fichero ya existe. Opciones disponibles:"
					+"\n1. Reescribir el fichero"
					+ "\n2. A�adir texto al final del fichero");

			n=entrada.nextInt(); 

			switch (n) {
			case 1:
				/*System.out.println("Introduce los datos del fichero");
				cadena=entrada.next();
				try{
					fos=new FileOutputStream(f);
					for(int i=0; i<cadena.length(); i++){
						c=cadena.charAt(i);
						fos.write(c);
					}
				}catch (IOException e){
					System.out.println(e);
				}
				try {
					fos.close();
				} catch (IOException e) {
					System.out.println(e);
				}*/
				entradaDatos(f);
				break;
			case 2:
				System.out.println("Introduce los datos para a�adirlos al fichero");
				cadena=entrada.next();
				try{
					fos= new FileOutputStream(f, true);
					for(int i=0; i<cadena.length(); i++){
						c=cadena.charAt(i);
						fos.write(c);
					}
				}catch(IOException e){
					System.out.println(e);
				}
				try {
					fos.close();
				} catch (IOException e) {
					System.out.println(e);
				}
				break;


			}
		}
		

		System.out.println("Leemos el fichero");
		FileInputStream fis=null;
		cadena=" ";
		try {
			fis= new FileInputStream(f);

			while(fis.available()>0){
				c=(char)fis.read();
				cadena+=c;
			}
			System.out.println(cadena);

		} catch (Exception e) {
			System.out.println(e);
		}
		try{
			fis.close();
		}catch(Exception e){
			System.out.println(e);
		}
	
	}
	
	
	
	
	static void entradaDatos(File f1){
		Scanner entrada= new Scanner(System.in);
		String cadena;
		char c;
		FileOutputStream fos=null;

		System.out.println("Introduce los datos del fichero");
		cadena=entrada.next();

		try{
			fos=new FileOutputStream(f1);
			for(int i=0; i<cadena.length(); i++){
				c=cadena.charAt(i);
				fos.write(c);
			}
		}catch (IOException e){
			System.out.println(e);
		}
		try {
			fos.close();
		} catch (IOException e) {
			System.out.println(e);
		}

	}

}
