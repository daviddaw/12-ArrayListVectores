package Ej_03_BufferedReader_Contar_lineas;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class ContarLineas {

	public static void main(String[] args) throws IOException {//exception del br (como scanner)
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));//como scanner
		File f= null; 
		BufferedWriter bw=null;
		String nombreF;
		String datos;
		int c=1;

		System.out.println("Introduce el nombre del fichero");
		nombreF=br.readLine();

		f= new File(nombreF);

		if(!(f.exists())){
			try{
				System.out.println("Introduce los datos del fichero");
				bw=new BufferedWriter(new FileWriter(f));//el que escribe en el fichero
				datos=br.readLine();
				while(!datos.equals("*")){
					bw.write(c+" "+datos);
					bw.newLine();
					datos=br.readLine();
					c++;
				}
			}catch(IOException e){
				System.out.println(e);
			}
		}
		else
			System.out.println("el fichero ya existe");

		try{
			bw.flush();
			bw.close();

		}catch(IOException e){
			System.out.println(e);
		}


		System.out.println("Ahora vamos a leer el fichero");


		BufferedReader br2=null;  
		try{
			br2=new BufferedReader(new FileReader(f));//el que lee el fichero
			datos=br2.readLine();
			while(datos!=null){
				System.out.println(datos);
				datos=br2.readLine();
			}
			
		}catch(IOException e){
			System.out.println(e);
		}


		System.out.println("lineas totales "+(c-1));
	
	}

}
