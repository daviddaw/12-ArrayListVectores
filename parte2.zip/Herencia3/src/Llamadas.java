
public abstract class Llamadas {
	
		private int nOrigen; 
		private int nDestino;
		private int duracion; 
		
		
		public Llamadas(){
			
		}
		
		
		public Llamadas(int nOrigen, int nDestino, int duracion){
			this.nOrigen=nOrigen; 
			this.nDestino=nDestino;
			this.duracion=duracion;
			
		}
		
		
		public abstract double precioLlam();


		public int getnOrigen() {
			return nOrigen;
		}


		public void setnOrigen(int nOrigen) {
			this.nOrigen = nOrigen;
		}


		public int getnDestino() {
			return nDestino;
		}


		public void setnDestino(int nDestino) {
			this.nDestino = nDestino;
		}


		public int getDuracion() {
			return duracion;
		}


		public void setDuracion(int duracion) {
			this.duracion = duracion;
		}


		@Override
		public String toString() {
			return "Llamadas [nOrigen=" + nOrigen + ", nDestino=" + nDestino
					+ ", duracion=" + duracion + "]";
		}
		
		

}
