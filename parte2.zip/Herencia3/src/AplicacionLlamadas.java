

public class AplicacionLlamadas {

	public static void main(String[] args) {
		
		Centralita centralita1 = new Centralita();
		
		Llamadas l1 = new LlamadasLocales(5551555, 4441444, 60);
		Llamadas l2= new LlamadasLocales(9991999, 8881888, 45);
		Llamadas p1 = new LlamadasProvinciales(21321, 5454864, 15, 1);
		Llamadas p2 = new LlamadasProvinciales(97854, 896746, 55, 2);
		Llamadas p3 = new LlamadasProvinciales(64646, 41286, 12, 3);
		
		
		centralita1.arrayllamadas[0]=l1;
		centralita1.arrayllamadas[1]=l2; 
		centralita1.arrayllamadas[2]=p1; 
		centralita1.arrayllamadas[3]=p2; 
		centralita1.arrayllamadas[4]=p3; 
		
		centralita1.verLlamadas();
		
	}

}
