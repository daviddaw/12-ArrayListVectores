

public class Centralita {
	
		 Llamadas[] arrayllamadas;
		 
		 
		 public Centralita(){
			 
			 arrayllamadas=new Llamadas[5];
			 
			
		 }
		 
		 
		 
	/*	 public void listaLlamadas(Llamadas llamadas){
			 for(int i=0; i<arrayllamadas.length; i++)
				 arrayllamadas[i]=llamadas;
		 }*/
		 
		 public void verLlamadas(){
			 for (int i = 0; i < arrayllamadas.length; i++) 
				 System.out.println(arrayllamadas[i].toString());
		 }
		 

}
