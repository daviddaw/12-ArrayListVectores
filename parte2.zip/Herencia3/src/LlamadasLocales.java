

public class LlamadasLocales extends Llamadas {

	
		public LlamadasLocales(){
			
		}
		
		public LlamadasLocales(int nOrigen, int nDestino, int duracion){
			super(nOrigen , nDestino, duracion);
		}
		
		
		public double precioLlam() {
			
			return super.getDuracion()*0.15;
		}

		@Override
		public String toString() {
			return  super.toString()+" LlamadasLocales [precioLlam()=" + precioLlam() + "]";
		}
		
		
	
}
