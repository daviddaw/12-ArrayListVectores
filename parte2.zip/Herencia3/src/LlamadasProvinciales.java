

public class LlamadasProvinciales extends Llamadas{
	
	
		private int franja;
		
		public LlamadasProvinciales(){
			
		}
		
		
		public LlamadasProvinciales(int nOrigen, int nDestino, int duracion, int franja){
			super(nOrigen, nDestino, duracion);
			this.franja=franja;
		}
		
		
		public double precioLlam(){
			double coste=0;
			switch(franja){
			case 1: 
				coste=super.getDuracion()*0.20;
				break;	
			case 2:
				coste=super.getDuracion()*0.25;
				break;
			case 3: 
				coste=super.getDuracion()*0.30;
				break;
			}
			return coste;
		}


		public int getFranja() {
			return franja;
		}


		public void setFranja(int franja) {
			this.franja = franja;
		}


		@Override
		public String toString() {
			return super.toString()+ " LlamadasProvinciales [precioLlam()=" + precioLlam()
					+ "]";
		}
		
		

}
