package Ej_02;

public class Hexagono extends Poligono{
	
	private double lado; 
	private double apotema;
	
	
	public Hexagono() {
		
	}
	
	public Hexagono(String color, int nLados,double lado, double apotema) {
		super(color, nLados);
		this.lado=lado; 
		this.apotema=apotema;
		
	}
	
	public double perimetro() {
		return lado*6;
	}
	

	
	public double area() {
		return ((lado*6)*apotema)/2;
	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}

	public double getApotema() {
		return apotema;
	}

	public void setApotema(double apotema) {
		this.apotema = apotema;
	}
	
	

	@Override
	public String toString() {
		return super.toString()+" Hexagono [lado=" + lado + ", apotema=" + apotema + "]";
	}
	
	
	
	
}
