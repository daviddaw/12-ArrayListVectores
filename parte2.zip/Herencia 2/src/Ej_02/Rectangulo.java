package Ej_02;

public class Rectangulo extends Poligono{


	private double base;
	private double altura;

	public Rectangulo() {
		
	}
	
	public Rectangulo( String color,int nLados, double base, double altura) {
		super(color, nLados);
		this.base=base; 
		this.altura=altura;
	}
	
	public double perimetro() {
		return base*2+altura*2;
	}
	
	public double area() {
		return base*altura;
	}

	public double getBase() {
		return base;
	}


	public void setBase(double base) {
		this.base = base;
	}

	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}
	

	@Override
	public String toString() {
		return super.toString()+", mi base es " + base + ", mi altura es " + altura + " .Mi perimetro es "+perimetro()+ " y mi area es "+area();
	}
}
