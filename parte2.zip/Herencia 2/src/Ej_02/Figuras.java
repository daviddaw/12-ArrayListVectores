package Ej_02;

public abstract class Figuras {
	
	protected String color;

	public Figuras(){
		
	}
	
	public Figuras(String color) {
		this.color=color;
	}
	
	
	public abstract double perimetro();
	public abstract double area();
	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Soy una Figura de color " + color;
	} 
	
	
	

}
