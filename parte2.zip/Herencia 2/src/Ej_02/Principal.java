package Ej_02;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Rectangulo rec1 = new Rectangulo("verde", 4, 5, 4);
		//System.out.println(rec1.toString());
		
		Triangulo tri1 = new Triangulo("rojo", 3, 6, 6);
		//System.out.println(tri1.toString());
		
		Hexagono h1 = new Hexagono("amarillo", 6, 5, 4);
		//System.out.println(h1.toString());
		
		
		Figuras arrayfiguras[]= {rec1, tri1, h1};
		
		for (int i = 0; i < arrayfiguras.length; i++) {
			System.out.println(arrayfiguras[i].toString());
		}
		
		
	}

}
