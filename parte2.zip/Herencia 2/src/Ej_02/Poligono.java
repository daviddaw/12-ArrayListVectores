package Ej_02;

public abstract class Poligono extends Figuras{
	
	private int nLados;
	
	public Poligono() {
		
	}
	
	
	
	public Poligono(String color, int nLados) {
		super(color);
		this.nLados=nLados;
	}

	public int getnLados() {
		return nLados;
	}

	public void setnLados(int nLados) {
		this.nLados = nLados;
	}

	
	@Override
	public String toString() {
		return super.toString()+" Ademas soy un Poligono con " + nLados + " lados";
	}
	
	
	
	

}
