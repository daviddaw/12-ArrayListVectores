package Ej_02;

public class Circulo extends Figuras{
	
	private double radio;
	
	public Circulo() {
		
	}
	
	public Circulo(String color, double radio) {
		super(color);
		this.radio=radio;
	}
	
	
	public double perimetro() {
		return 2*3.14*radio;
	}
	
	
	public double area() {
		return 3.14*Math.pow(radio, 2);
	}
	

	public double getRadio() {
		return radio;
	}

	
	public void setRadio(double radio) {
		this.radio = radio;
	}

	@Override
	public String toString() {
		return "Circulo [radio=" + radio + "]";
	}

	
	
	
}
