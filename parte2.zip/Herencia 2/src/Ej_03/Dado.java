package Ej_03;

public class Dado extends Sorteo{
	
	public Dado() {
		super.posibilidades=6;
	}
	
	public void lanzar() {
		int num;
		num=(int)(Math.random()*6+1);
		System.out.println(num);
	}

	
	
	
	
	
	
		

}
