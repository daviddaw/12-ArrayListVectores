package Ej_03;



public abstract class Sorteo {

	protected int posibilidades;

	public Sorteo() {

	}

	/*public Sorteo(int posibilidades) {
		this.posibilidades = posibilidades;
	}*/

	public int getPosibilidades() {
		return posibilidades;
	}

	public void setPosibilidades(int posibilidades) {
		this.posibilidades = posibilidades;
	}

	public abstract void lanzar();
	
	

	public double probabilidad() {
		return 1/posibilidades;

	}

	public void verDatos() {
		System.out.println("posibilidades: " +getPosibilidades());
		System.out.println("probabilidad: " +probabilidad());

	}


}


	
	

