package Ej_03;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		
		Scanner entrada = new Scanner(System.in);
		int op;

		do {
			System.out.println("Elige que jugar: \n1) Dados \n2) Moneda \n3) Carta");
			op=entrada.nextInt();
		}while(op<0 || op>3);

		switch(op) {

		case 1:
			Dado d1 = new Dado();
			d1.verDatos();
			System.out.println("Sacas un:");
			d1.lanzar();
			break;

		case 2:
			Moneda m1= new Moneda();
			m1.verDatos();
			System.out.println("Ha salido:");
			m1.lanzar();
			break;

		case 3:
			Carta c1= new Carta();
			c1.verDatos();
			System.out.println("Sacas un:");
			c1.lanzar();
			break;

		}
	}

}
