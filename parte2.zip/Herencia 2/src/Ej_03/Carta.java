package Ej_03;

public class Carta extends Sorteo {

	public Carta() {
		super.posibilidades=40;
	}

	public void lanzar() {

		String arrayPalo[]={"Oros","Bastos","Copas","Espadas"};
		String arrayNombre[]= {"As","Dos","Tes","Cuatro","Cinco","Seis","Siete","Sota","Caballo","Rey"};

		int carta, palo;

		carta=(int)(Math.random()*3+0);
		palo=(int)(Math.random()*9+0);

		System.out.println(arrayNombre[palo]+" de "+arrayPalo[carta]);

	}



}
