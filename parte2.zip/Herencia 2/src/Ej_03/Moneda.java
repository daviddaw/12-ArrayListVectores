package Ej_03;

public class Moneda extends Sorteo{

	public Moneda() {
		super.posibilidades=2;
	}
	
	public void lanzar() {
		int num; 
		num=(int)(Math.random()*1+0);
		
		if(num==0)
			System.out.println("cara");
		else 
			System.out.println("cruz");
		
		
	}
	


}
