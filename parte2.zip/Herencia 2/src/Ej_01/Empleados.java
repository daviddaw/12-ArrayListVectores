package Ej_01;

public abstract class Empleados {
	
	private String nombre; 
	private String dni;
	private int tlf;
	
	
	public Empleados() {
		
	}
	
	
	public Empleados(String nombre, String dni, int tlf) {
		this.nombre=nombre;
		this.dni=dni;
		this.tlf=tlf;
	}
	
	
	public abstract double sueldoMes();
	
	
	
	public String getNombre() {
		return nombre;
	}
	
	
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	public String getDni() {
		return dni;
	}
	
	
	
	public void setDni(String dni) {
		this.dni = dni;
	}
	
	
	
	public int getTlf() {
		return tlf;
	}
	
	
	
	public void setTlf(int tlf) {
		this.tlf = tlf;
	}


	@Override
	public String toString() {
		return "Empleados [nombre=" + nombre + ", dni=" + dni + ", tlf=" + tlf + "]";
	}
	

	public String mostarsueldo() {
		return "Empleados [nombre=" + nombre + " sueldoMes="+sueldoMes()+ "]";
	}
	
	

}
