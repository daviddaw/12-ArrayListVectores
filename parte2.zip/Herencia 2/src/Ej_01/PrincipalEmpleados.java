package Ej_01;

public class PrincipalEmpleados {

	public static void main(String[] args) {
		
		Efijos empf1 = new Efijos("pepe", "asdasd", 78455, 800);
		Efijos empf2 = new Efijos("ana", "646f", 4664687, 900);
		Ehoras emph1 = new Ehoras("juan", "787ff3", 6654, 50, 10);
		Ehoras emph2 = new Ehoras("pablo", "46546", 6565431, 14, 18);

	
		
		
		
		Empleados arrayemp[]={empf1, empf2, emph1, emph2};
	
		for (int i = 0; i < arrayemp.length; i++) {
			System.out.println(arrayemp[i].mostarsueldo());
			
		}
		//Para mostrar todos los datos usar toString
		

	}

}
