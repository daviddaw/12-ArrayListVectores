package Ej_01;

public class Ehoras extends Empleados{
	
	private int nHoras;
	private double salarioHora;
	

	
	public Ehoras() {
		
	}
	
	public Ehoras(String nombre, String dni, int tlf, int nHoras, double salarioHora) {
		super(nombre, dni, tlf);
		this.nHoras=nHoras;
		this.salarioHora=salarioHora;
	}
	
	public double sueldoMes() {
		return nHoras*salarioHora;
		
	}

	public int getnHoras() {
		return nHoras;
	}

	public void setnHoras(int nHoras) {
		this.nHoras = nHoras;
	}

	public double getSalarioHora() {
		return salarioHora;
	}

	public void setSalarioHora(double salarioHora) {
		this.salarioHora = salarioHora;
	}

	@Override
	public String toString() {
		return super.toString()+" Ehoras [nHoras=" + nHoras + ", salarioHora=" + salarioHora + ", sueldoMes()=" + sueldoMes() + "]";
	}

	
	public String mostarSueldo() {
		return super.toString()+ " , sueldoMes()=" + sueldoMes()+"]";
	}
	
	
}
