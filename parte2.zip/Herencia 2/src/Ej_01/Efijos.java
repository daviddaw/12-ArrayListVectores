package Ej_01;

public class Efijos extends Empleados{
	
	private double salario;
	
	
	public Efijos() {
		
	}
	
	
	public Efijos(String nombre, String dni, int tlf, double salario) {
		super(nombre, dni, tlf);
		this.salario=salario;
	}
	
	public double sueldoMes() {
		return this.salario;
	}


	public double getSalario() {
		return salario;
	}


	public void setSalario(double salario) {
		this.salario = salario;
	}


	@Override
	public String toString() {
		return super.toString()+" Efijos [salario=" + salario + "]";
	}
	
	public String mostarSueldo() {
		return super.toString()+ " Efijos [salario=" + salario + "]";
	}

}
